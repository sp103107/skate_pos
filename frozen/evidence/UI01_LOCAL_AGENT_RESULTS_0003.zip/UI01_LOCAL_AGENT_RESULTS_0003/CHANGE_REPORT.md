# rc.6 change report

Local start/stop launchers and persistent demo workspace. Baseline rc.5 acceptance disposition 0002 retained. F-01/F-02/F-03 not repaired. Native Windows launcher lifecycle NOT_RUN.
