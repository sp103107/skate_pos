# Evidence Correction Appendix 0001

**Kind:** summary-derivation correction only  
**Not a new test run.** Results archive 0002 and sealed candidate rc.5 are unchanged.  
**Participant:** `skate-ui01-local-review` (LOCAL_UI01_TESTER)  
**Operator:** Stephen  
**Authorization:** Sorcerer "RC.5 RESULTS RECEIVED — READY FOR INDEPENDENT REVIEW WITH OPEN FINDINGS" (ARC H01)

## 1. Immutable archive hashes (re-verified at appendix write)

| Archive | SHA-256 |
| --- | --- |
| `UI01_LOCAL_AGENT_RESULTS_0002.zip` | `0d2b94422072563e9df272435913a01172a13507d8b46d29f9d362d291a3ffaf` |
| `Skate_Inventory_UI_Candidate_v0.1.0-rc.5.zip` | `14275ffb7d892ff61345f10a5185aebae872f19249903f509417b49a75ce7215` |
| `UI01_LOCAL_AGENT_RESULTS_0001.zip` (unchanged baseline) | `3615fa61ea603582c77e56c25def8c0f0a42650b06e747c6ea7b4e6d04c47433` |
| `Skate_Inventory_UI_Candidate_v0.1.0-rc.4.zip` (parent) | `fd4d6a2f989f08c610c317dafa22c30255a307feb26d175b87f7cb17886de518` |
| `Skate_Inventory_Use_System_Core_Capsule_v0.3.1-rc.1.zip` | `40ffdac4d0eb2bbbd6dd72cce2be0ec953842eb4b34ff7934cc6bab5f53b27e3` |
| Nested `UI01_RC5_CHECKS_RETURN.zip` (inside 0002) | `a8a0e023a7d380904094de3d68d60fef840f015aa71cafbe23d1ba002b3f1e3b` |
| Nested `UI01_RC5_BROWSER_RETURN.zip` (inside 0002) | `682bb1074a2906738342ca0a5c528d9e3ba8c70e8e0f9d3a8611c4278c693f53` |

Linux and Windows copies of results 0002 and candidate rc.5 were re-hashed at write time and match the table above. This appendix does **not** rewrite, repackage, or replace those archives.

## 2. Incorrect field in RESULT_SUMMARY.json

**Archive path:** `UI01_LOCAL_AGENT_RESULTS_0002/RESULT_SUMMARY.json`  
**Field path:** `rc5_fresh.adapter.status`  
**Incorrect value as sealed:** `"FAIL"`

Related counter fields as sealed (not themselves wrong as counts, but inconsistent with the status string):

```json
"rc5_fresh": {
  "adapter": {
    "status": "FAIL",
    "unique_cases": 18,
    "failures": [],
    "errors": [],
    "skips": [],
    "case_ids": [ /* 18 case IDs */ ]
  }
}
```

## 3. Correct scoped interpretation

| Item | Correct value |
| --- | --- |
| Raw measurement status | `PASS_FOREMAN_MEASUREMENT_NOT_JUDGE` |
| Tests run / passed | 18 / 18 |
| Failures / errors / skips | `[]` / `[]` / `[]` (empty; zero failures) |
| Scope | Operator / Foreman measurement on installed Core with synthetic seed — **not** independent Judge PASS |
| Summary field that should have been written | `"PASS"` or preferably the raw status string `PASS_FOREMAN_MEASUREMENT_NOT_JUDGE` |

Supporting evidence (authoritative over the summary field):

1. Inside results 0002: `evidence/UI01_RC5_CHECKS_RETURN.zip` → `adapter/ADAPTER_RESULT.json`  
   - SHA-256 of that nested zip: `a8a0e023a7d380904094de3d68d60fef840f015aa71cafbe23d1ba002b3f1e3b`
2. Inside sealed candidate rc.5: `evidence/rc5_local/checks/adapter/ADAPTER_RESULT.json`  
   - Candidate zip SHA-256: `14275ffb7d892ff61345f10a5185aebae872f19249903f509417b49a75ce7215`
3. Checks run summary (same nested zip): `RUN_SUMMARY.json` status `PASS_SCOPED_OPERATOR_MEASUREMENT_NOT_JUDGE`
4. Receipt inside 0002: `SKATE_UI01_LOCAL_RC5_RECEIPT_0001.json` → `measurements.checks` = `PASS_SCOPED_OPERATOR_MEASUREMENT_NOT_JUDGE`
5. Narrative inside 0002: `LOCAL_AGENT_REPORT.md` states adapter 18 cases, 0 failures/errors/skips

## 4. Root cause (derivation bug, not a failed adapter run)

When assembling `RESULT_SUMMARY.json`, the return assembler evaluated:

```text
'PASS' if adapter_res.get('failures', 0) == 0 and adapter_res.get('errors', 0) == 0 else 'FAIL'
```

Raw `ADAPTER_RESULT.json` stores `failures` and `errors` as **empty lists** (`[]`), not integers. In Python, `[] == 0` is `False`, so the expression selected `"FAIL"` even though there were zero failures and zero errors.

Other fields derived from the same raw file (case IDs, counts) and the disposition / receipt / report paths that used the kit `RUN_SUMMARY` status were written correctly. Disposition `COMPLETE_FOR_INDEPENDENT_REVIEW` and top-level `status` `PASS_SCOPED_OPERATOR_MEASUREMENT_NOT_JUDGE` remain valid; only the nested summary field `rc5_fresh.adapter.status` is wrong.

## 5. Confirmation

- This document is an **evidence clarification appendix**.
- No adapter, browser, checks, or supplemental suite was re-run for this correction.
- `UI01_LOCAL_AGENT_RESULTS_0002.zip` and `Skate_Inventory_UI_Candidate_v0.1.0-rc.5.zip` are **not** overwritten or altered.
- Independent review should treat `rc5_fresh.adapter.status == "FAIL"` as a known summary typo and use the raw `ADAPTER_RESULT.json` paths above as the measurement of record.
