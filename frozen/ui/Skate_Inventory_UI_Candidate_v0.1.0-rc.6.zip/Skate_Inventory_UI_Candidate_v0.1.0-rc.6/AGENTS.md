# AGENTS — UI01 local coding-agent entry (rc.6)

Participant: `skate-ui01-local-review`  
Role: local implementation / measurement against sealed Core  
Distribution: **HANDOFF_ONLY**

## Read first

1. `LOCAL_RUN.md` — setup vs daily start/stop
2. `context/CURRENT_ASSIGNMENT.json` and `context/RESUME.json`
3. Acceptance disposition bind: baseline rc.5 `PASS_WITH_KNOWN_LIMITATIONS` (evidence review; not fresh Judge runtime)

## Task Bump stages (meta skill)

`INTENT → PLAN → BUILD → VALIDATE → PACKAGE → DISTRIBUTE` with CLOSE/RESUME.  
BUILD ends at **CANDIDATE_COMPLETE**, never PASS.  
Scheduler lifecycle is separate: work BLOCKED/FAILED ≠ scheduler DISABLED.

## Do

- Use `./start_all.sh` / `start_all.bat` and matching stop scripts.
- Keep demo data in `.local-runtime/demo` (persistent; never wipe on start/stop).
- Bind `127.0.0.1` only.
- Reuse frozen Core **0.3.1-rc.1**.
- Apply Stephen’s project-local policy: only system/app-breaking issues gate acceptance; retain F-01/F-02/F-03.

## Do not

- Silently pip/npm/browser-install on daily start
- Substitute Core 0.3.0
- Repair F-01 or redesign navigation unless a new bounded assignment says so
- Public listeners, rentals, UI freeze, release, upload, or Control Plane promotion
- Broad process-name kills

## Resume

Resume from durable context/receipts. Do not redo validated predecessor work unless artifacts are missing or explicitly superseded.
