"""Install only the frozen Core wheel into the current pre-provisioned venv."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile,zipfile
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--core-zip',required=True);a=p.parse_args()
    if sys.prefix==sys.base_prefix:p.error('Activate a separately provisioned virtual environment first')
    lock=json.loads((ROOT/'lineage/CORE_DEPENDENCY.json').read_text());data=Path(a.core_zip).read_bytes()
    if hashlib.sha256(data).hexdigest()!=lock['core_zip_sha256']:p.error('Frozen Core ZIP mismatch')
    with zipfile.ZipFile(a.core_zip) as z:
        if z.testzip() is not None:p.error('Core ZIP CRC mismatch')
        b=z.read('Skate_Inventory_Use_System_Core_Capsule_v0.3.1-rc.1/releases/wheels/'+lock['wheel_filename'])
    if hashlib.sha256(b).hexdigest()!=lock['wheel_sha256']:p.error('Frozen wheel mismatch')
    with tempfile.TemporaryDirectory(prefix='ui01-wheel-install-') as tmp:
        wheel=Path(tmp)/lock['wheel_filename'];wheel.write_bytes(b)
        subprocess.run([sys.executable,'-m','pip','install','--no-index','--no-deps',str(wheel)],check=True)
    sys.path.insert(0,str(ROOT/'adapter'));from bridge import verify_installed_core
    print(json.dumps(verify_installed_core()))
if __name__=='__main__':main()
