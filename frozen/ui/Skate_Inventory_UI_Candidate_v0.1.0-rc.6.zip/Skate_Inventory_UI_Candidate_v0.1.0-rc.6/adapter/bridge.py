"""UI01 trusted-local, serialized loopback bridge. No production API or identity service."""
from pathlib import Path
import argparse,datetime,hashlib,json,secrets,sys,tempfile,uuid
from http.server import BaseHTTPRequestHandler,HTTPServer
from importlib import metadata
from skate_inventory_core import SkateInventoryCore,CoreConfig
from skate_inventory_core.facades import CoreRequestError,validate_request

ROOT=Path(__file__).resolve().parents[1]
COMMANDS=frozenset({'scan_asset','register_pair','register_component','link_pair','verify_inventory','transfer_location'})
QUERIES=frozenset({'list_inventory','get_pair','find_asset','asset_history','runtime_status'})
def envelope(name,payload,*,version=None):
    e={'command_id':str(uuid.uuid4()),'schema_version':'0.1.0','command_name':name,'requested_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'actor_id':'ui01-synthetic-operator','actor_role':'OWNER_ADMIN','device_id':'DEV-COUNTER','location_id':'LOC-RINK','idempotency_key':'ui01:'+str(uuid.uuid4()),'payload':payload,'offline_created':False}
    if version is not None:e['expected_pair_version']=version
    return e

def verify_installed_core():
    import skate_inventory_core,skate_registry
    if metadata.version('skate-inventory-core')!='0.3.1rc1':raise RuntimeError('CORE_VERSION_MISMATCH')
    site=Path(skate_inventory_core.__file__).resolve().parent.parent
    if not site.is_relative_to(Path(sys.prefix).resolve()) or not Path(skate_registry.__file__).resolve().is_relative_to(site):raise RuntimeError('CORE_NOT_INSTALLED_IN_ENVIRONMENT')
    for f,h in json.loads((ROOT/'lineage/INSTALLED_CORE_LOCK.json').read_text()).items():
        if hashlib.sha256((site/f).read_bytes()).hexdigest()!=h:raise RuntimeError('CORE_BYTE_MISMATCH:'+f)
    return {'distribution':'skate-inventory-core==0.3.1rc1','origin':str(site),'files_verified':len(json.loads((ROOT/'lineage/INSTALLED_CORE_LOCK.json').read_text()))}

class Adapter:
    def __init__(self,core):self.core=core
    def query(self,request):
        name,params=validate_request('query',request)
        if name not in QUERIES:raise CoreRequestError('QUERY_GATED')
        return self.core.query(name,params)
    def submit(self,e):
        if not isinstance(e,dict):raise CoreRequestError('INVALID_REQUEST')
        if e.get('command_name') not in COMMANDS:raise CoreRequestError('COMMAND_GATED')
        # Core performs contract/payload/role/reference/idempotency/version validation.
        return self.core.execute(e)

def seed(core):
    from skate_registry.reference_data import ReferenceDataService
    ref=ReferenceDataService(core.db,core.contracts)
    ref.add_organization({'org_id':'ORG-OWNER','name':'Synthetic Owner','org_type':'ASSET_OWNER'})
    for code,title,kind in [('LOC-RINK','Synthetic Rink','RINK'),('LOC-STORAGE','Synthetic Storage','STORAGE')]:ref.add_location({'location_id':code,'name':title,'location_type':kind})
    ref.add_device({'device_id':'DEV-COUNTER','name':'Synthetic Counter','device_type':'COUNTER_TABLET'})
    adapter=Adapter(core);receipts=[]
    for number,size in [('0900','8'),('0901','9')]:
        pid='SKT-'+number
        pair={'pair_id':pid,'owner_org_id':'ORG-OWNER','size_system':'US_MENS','size_value':size,'category':'HOCKEY','home_location_id':'LOC-RINK','current_location_id':'LOC-RINK','custodian_org_id':'ORG-OWNER'}
        commands=[('register_pair',{'pair':pair})]+[('register_component',{'component':{'component_id':pid+'-'+side,'pair_id':pid,'side':side,'label_identifier':pid+'-'+side,'current_location_id':'LOC-RINK'}}) for side in ('L','R')]+[('link_pair',{'pair_id':pid,'left_component_id':pid+'-L','right_component_id':pid+'-R'})]
        for name,payload in commands:
            receipt=adapter.submit(envelope(name,payload));assert receipt['status']=='ACCEPTED',receipt;receipts.append(receipt)
    return receipts

def new_workspace(raw,do_seed):
    p=Path(raw)
    if not p.is_absolute() or p.is_symlink() or p.exists():raise ValueError('Use a nonexistent absolute temporary workspace')
    p=p.resolve()
    if p.parent!=Path(tempfile.gettempdir()).resolve() or not p.name.startswith('skate-ui01-demo-'):raise ValueError('Use a new direct system-temp skate-ui01-demo-* workspace; no DB override')
    p.mkdir();core=SkateInventoryCore(CoreConfig(p/'synthetic.db')).initialize()
    receipts=seed(core) if do_seed else []
    (p/'SEED_RECEIPTS.json').write_text(json.dumps(receipts,indent=2)+'\n')
    return p,core

def open_workspace(raw,do_seed):
    """Open or create a persistent absolute workspace (local launcher path). Never wipes an existing DB."""
    p=Path(raw)
    if not p.is_absolute() or p.is_symlink():raise ValueError('Use an absolute non-symlink workspace path')
    p=p.resolve()
    if p.exists() and not p.is_dir():raise ValueError('workspace path is not a directory')
    db=p/'synthetic.db'
    if p.exists() and db.is_file():
        core=SkateInventoryCore(CoreConfig(db)).initialize()
        return p,core
    if p.exists() and any(p.iterdir()):raise ValueError('existing workspace is not a synthetic.db workspace')
    p.mkdir(parents=True,exist_ok=True)
    core=SkateInventoryCore(CoreConfig(db)).initialize()
    receipts=seed(core) if do_seed else []
    (p/'SEED_RECEIPTS.json').write_text(json.dumps(receipts,indent=2)+'\n')
    return p,core

class Server(HTTPServer):
    def __init__(self,port,adapter,identity,workspace):
        super().__init__(('127.0.0.1',port),Handler)
        self.adapter=adapter;self.identity=identity;self.workspace=workspace
        self.origin='http://127.0.0.1:'+str(self.server_port);self.token=secrets.token_urlsafe(32)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send(self,status,value,mime='application/json'):
        b=json.dumps(value,allow_nan=False).encode() if mime=='application/json' else value
        self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(b)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.end_headers();self.wfile.write(b)
    def error(self,status,code):self.send(status,{'error':{'code':code}})
    def perimeter(self):
        if self.headers.get('Host')!='127.0.0.1:'+str(self.server.server_port):self.error(403,'HOST_FORBIDDEN');return False
        origin=self.headers.get('Origin')
        if origin is not None and origin!=self.server.origin:self.error(403,'ORIGIN_FORBIDDEN');return False
        return True
    def do_GET(self):
        if not self.perimeter():return
        if self.path=='/api/status':
            self.send(200,{'mode':'ACTUAL_CORE_SYNTHETIC_ONLY','identity':self.server.identity,'token':self.server.token,'origin':self.server.origin,'workspace':str(self.server.workspace),'capabilities':{'commands':sorted(COMMANDS),'queries':sorted(QUERIES),'recovery':False,'rental':False},'context':{'actor_id':'ui01-synthetic-operator','actor_role':'OWNER_ADMIN','device_id':'DEV-COUNTER','location_id':'LOC-RINK'},'locations':['LOC-RINK','LOC-STORAGE']});return
        files={'/':('frontend/index.html','text/html'),'/app.js':('frontend/app.js','text/javascript'),'/adapter.js':('frontend/adapter.js','text/javascript'),'/app.css':('frontend/app.css','text/css'),'/inventory.png':('history/UI00_architecture/assets/icons/inventory.png','image/png')}
        if self.path not in files:self.error(404,'NOT_FOUND');return
        f,m=files[self.path];self.send(200,(ROOT/f).read_bytes(),m)
    def do_POST(self):
        if not self.perimeter():return
        if self.path not in ('/api/query','/api/command'):self.error(404,'PATH_GATED');return
        if not secrets.compare_digest(self.headers.get('X-UI01-Token',''),self.server.token):self.error(403,'TOKEN_REQUIRED');return
        if self.headers.get('Content-Type')!='application/json' or self.headers.get('Transfer-Encoding'):self.error(400,'INVALID_BODY');return
        try:n=int(self.headers.get('Content-Length','0'))
        except ValueError:self.error(400,'INVALID_LENGTH');return
        if n<1 or n>16384:self.error(413,'BODY_LIMIT');return
        self.connection.settimeout(5)
        try:
            def pairs(items):
                d={}
                for k,v in items:
                    if k in d:raise ValueError('duplicate key')
                    d[k]=v
                return d
            req=json.loads(self.rfile.read(n),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
            result=self.server.adapter.query(req) if self.path=='/api/query' else self.server.adapter.submit(req)
            if self.path=='/api/command':
                status=200 if result['status'] in ('ACCEPTED','DUPLICATE') else 409 if result['status']=='CONFLICT' else 422
                self.send(status,{'receipt':result})
            else:self.send(200,{'result':result})
        except CoreRequestError as e:self.error(400,e.code)
        except (ValueError,TypeError,RecursionError):self.error(400,'INVALID_REQUEST')
        except Exception as e:
            # Do not expose tracebacks/paths as HTTP errors; details stay local.
            print(json.dumps({'bridge_error':type(e).__name__}),file=sys.stderr);self.error(503,'RUNTIME_UNAVAILABLE')
    def do_OPTIONS(self):self.error(405,'METHOD_FORBIDDEN')
    def do_PUT(self):self.error(405,'METHOD_FORBIDDEN')
    def do_DELETE(self):self.error(405,'METHOD_FORBIDDEN')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    g=parser.add_mutually_exclusive_group(required=True)
    g.add_argument('--new-workspace');g.add_argument('--workspace')
    parser.add_argument('--seed-synthetic',action='store_true');parser.add_argument('--port',type=int,default=0)
    args=parser.parse_args();identity=verify_installed_core()
    if not 0<=args.port<=65535:parser.error('invalid port')
    if args.new_workspace:workspace,core=new_workspace(args.new_workspace,args.seed_synthetic)
    else:workspace,core=open_workspace(args.workspace,args.seed_synthetic)
    server=Server(args.port,Adapter(core),identity,workspace)
    print(json.dumps({'origin':server.origin,'mode':'ACTUAL_CORE_SYNTHETIC_ONLY','workspace':str(workspace),'identity':identity}),flush=True)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close();core.shutdown()
if __name__=='__main__':main()
