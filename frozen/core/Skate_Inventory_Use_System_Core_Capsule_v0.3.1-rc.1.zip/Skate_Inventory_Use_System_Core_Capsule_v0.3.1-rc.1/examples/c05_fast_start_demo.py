"""Synthetic RC runbook. Refuses existing/non-temporary workspaces; never accepts a DB override."""
from pathlib import Path
import argparse,datetime,json,os,sqlite3,subprocess,sys,tempfile,uuid
from copy import deepcopy


def logical_state(path):
    with sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro',uri=True) as conn:
        schema=conn.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
        tables={}
        for row in schema:
            if row[0]=='table':
                name='"'+row[1].replace('"','""')+'"'
                tables[row[1]]=conn.execute('SELECT rowid,* FROM '+name+' ORDER BY rowid').fetchall()
        return {'schema':schema,'tables':tables}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--new-workspace',required=True)
    args=parser.parse_args();root=Path(args.new_workspace)
    if not root.is_absolute():parser.error('workspace must be absolute')
    root=root.resolve();tmp=Path(tempfile.gettempdir()).resolve()
    if root.parent!=tmp or not root.name.startswith('skate-rc-demo-') or root.exists():
        parser.error('use a nonexistent skate-rc-demo-* direct child of the system temporary directory')
    if os.environ.get('PYTHONPATH'):parser.error('unset PYTHONPATH; use the installed RC environment')
    import skate_inventory_core,skate_registry
    from importlib import metadata
    for module in [skate_inventory_core,skate_registry]:
        if not Path(module.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()):parser.error('package is not installed in this environment')
    if metadata.version('skate-inventory-core')!='0.3.1rc1':parser.error('this runbook requires RC1')
    root.mkdir();requests=root/'requests';requests.mkdir();db=root/'synthetic.db';transcript=[]
    binaries=Path(sys.executable).parent

    def cli(arguments,*,legacy=False,module=False,expect=0):
        prefix=[str(binaries/('skate-registry' if legacy else 'skate-inventory'))]
        if module:prefix=[sys.executable,'-m','skate_inventory_core']
        cmd=prefix+list(map(str,arguments));p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=30)
        record={'argv':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr};transcript.append(record)
        (root/'TRANSCRIPT.json').write_text(json.dumps(transcript,indent=2)+'\n')
        assert p.returncode==expect,record
        assert 'Traceback' not in p.stderr,record
        return json.loads(p.stdout or p.stderr)

    def request(kind,name,params,*,database=db,module=False,expect=0):
        path=requests/(name+'.json');path.write_text(json.dumps({'name':name,'params':params},indent=2)+'\n')
        out=cli(['--db',database,kind,'--file',path],module=module,expect=expect)
        return out.get('result',out)

    def command(name,payload,*,saved=None,database=db,expect=0):
        obj=saved or {'command_id':str(uuid.uuid4()),'schema_version':'0.1.0','command_name':name,
                     'requested_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),
                     'actor_id':'synthetic-demo','actor_role':'OWNER_ADMIN','device_id':'DEV-COUNTER',
                     'location_id':'LOC-RINK','idempotency_key':'c05-demo:'+str(uuid.uuid4()),'payload':payload,'offline_created':False}
        path=requests/(name+'.json');path.write_text(json.dumps(obj,indent=2)+'\n')
        out=cli(['--db',database,'execute','--file',path],module=name=='scan_asset',expect=expect)
        return obj,out['receipt']

    # Init is one-shot; run/default and health return readiness then exit.
    cli(['--db',db,'init'],module=True);cli(['--db',db,'run']);cli(['--db',db],module=True)
    assert cli(['--db',db,'health'])['report']['status']=='HEALTHY'
    for args in [('add-org','ORG-OWNER','Synthetic Owner','ASSET_OWNER'),('add-org','ORG-RINK','Synthetic Rink','VENUE_OPERATOR'),
                 ('add-location','LOC-RINK','Synthetic Rink','RINK'),('add-location','LOC-STORAGE','Synthetic Storage','STORAGE'),
                 ('add-device','DEV-COUNTER','Synthetic Counter','COUNTER_TABLET')]:cli(['--db',db,*args],legacy=True)
    pair={'pair_id':'SKT-0900','owner_org_id':'ORG-OWNER','size_system':'US_MENS','size_value':'8','category':'HOCKEY','home_location_id':'LOC-RINK','current_location_id':'LOC-RINK','custodian_org_id':'ORG-OWNER'}
    command('register_pair',{'pair':pair})
    for side in ['L','R']:command('register_component',{'component':{'component_id':'SKT-0900-'+side,'pair_id':'SKT-0900','side':side,'label_identifier':'SKT-0900-'+side,'current_location_id':'LOC-RINK'}})
    command('link_pair',{'pair_id':'SKT-0900','left_component_id':'SKT-0900-L','right_component_id':'SKT-0900-R'})
    command('scan_asset',{'identifier':'SKT-0900-L'});command('verify_inventory',{'pair_id':'SKT-0900','observed_component_ids':['SKT-0900-L','SKT-0900-R']})
    transfer,receipt=command('transfer_location',{'pair_id':'SKT-0900','to_location_id':'LOC-STORAGE'})
    (requests/'original_transfer.json').write_text(json.dumps(transfer,indent=2)+'\n')
    command('replace_label',{'component_id':'SKT-0900-L','new_label_identifier':'SKT-0901-L'});command('mark_component_missing',{'component_id':'SKT-0900-R'})
    note=root/'synthetic_note.txt';note.write_text('Synthetic supporting note; no operator data.')
    evidence=request('runtime','add_evidence',{'file_path':str(note),'related_event_id':receipt['event_ids'][0]})
    command('record_correction',{'target_event_id':receipt['event_ids'][0],'correction_mode':'EVIDENCE_ADDENDUM','reason':'Synthetic note','evidence_refs':[evidence['attachment_id']]})
    before=logical_state(db)
    assert request('query','get_pair',{'pair_id':'SKT-0900'})['pair_id']=='SKT-0900'
    assert request('query','list_inventory',{})[0]['pair_id']=='SKT-0900'
    assert request('query','find_asset',{'identifier':'SKT-0900-L'},module=True)['active_label'] is False
    assert request('query','asset_history',{'pair_id':'SKT-0900'})[-1]['event_type']=='CORRECTION_RECORDED'
    assert request('query','runtime_status',{'deep':True})['status']=='HEALTHY'
    assert request('runtime','health',{'deep':True})['status']=='HEALTHY'
    assert request('runtime','verify_ledger',{})['ok']
    assert request('runtime','replay_check',{})['semantic_match']
    assert request('runtime','export_evidence',{})['kind']=='EVIDENCE_METADATA_ONLY'
    assert logical_state(db)==before
    bad=requests/'invalid_query.json';bad.write_text(json.dumps({'name':'list_inventory','params':{'extra':True}}))
    assert cli(['--db',db,'query','--file',bad],expect=2)['error']['code']=='INVALID_PARAMS'
    assert logical_state(db)==before
    request('runtime','checkpoint',{'metadata':{'reason':'C05 synthetic acceptance'}})
    assert request('runtime','rebuild_projections',{})['semantic_match']
    bundle=root/'recovery.zip';target=root/'restored.db';request('runtime','export_recovery',{'out_path':str(bundle)})
    request('runtime','restore_recovery',{'bundle_path':str(bundle),'target_db_path':str(target)},module=True)
    restored=logical_state(target)
    _,retry=command('transfer_location',{},saved=transfer,database=target);assert retry['status']=='DUPLICATE' and retry['event_ids']==receipt['event_ids']
    changed=deepcopy(transfer);changed['command_id']=str(uuid.uuid4());changed['payload']['to_location_id']='LOC-RINK'
    _,conflict=command('transfer_location',{},saved=changed,database=target,expect=4);assert conflict['error']['code']=='IDEMPOTENCY_CONFLICT'
    assert logical_state(target)==restored
    rejection=request('runtime','restore_recovery',{'bundle_path':str(bundle),'target_db_path':str(target)},expect=2)
    assert 'error' in rejection and logical_state(target)==restored
    assert cli(['--db',target,'health'],module=True)['report']['status']=='HEALTHY'
    result={'status':'PASS','candidate':'0.3.1-rc.1','distribution':'0.3.1rc1','workspace':str(root),'calls':len(transcript),'synthetic_only':True,'PYTHONPATH':os.environ.get('PYTHONPATH'),'query_no_logical_writes':True,'restored_retry_conflict_continuity':True,'protected_target_rejected':True,'no_network_service_required':True,'attachment_bytes_transport_claimed':False}
    (root/'DEMO_RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':main()
