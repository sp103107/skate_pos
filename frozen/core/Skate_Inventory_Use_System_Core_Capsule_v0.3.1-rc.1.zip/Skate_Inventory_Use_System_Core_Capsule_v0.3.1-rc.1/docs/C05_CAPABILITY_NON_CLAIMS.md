# RC capability and boundary matrix

| Surface | Candidate behavior | Not claimed |
| --- | --- | --- |
| Composition | One local Core; shared repaired registry/contracts/spine; deterministic shutdown | Separate mutable runtime lineages or background service |
| Console/module | skate-inventory / python -m skate_inventory_core; init/run/health/execute/query/runtime | UI/API, daemon, network listener |
| Commands | Existing registration/link/scan/verify/transfer/label/missing/correction envelopes and receipt/idempotency semantics | New business behavior or complete rental lifecycle |
| Queries | get_pair, list_inventory, find_asset, asset_history, runtime_status; logical no-write | Raw SQL dispatcher or authenticated remote access |
| Administration | health, checkpoint, replay_check, rebuild_projections, verify_ledger, add_evidence, export_evidence, export_recovery, restore_recovery; explicit trusted-local calls | Inherited command-role enforcement or authenticated identity |
| Reference seed | Existing skate-registry trusted-local compatibility | Automatic production inventory/reference seeding |
| Recovery | Existing full-export cutoff, new-target restore, retry/conflict continuity and fail-closed protections | Attachment-byte transport, legacy migration, tail merge, stronger crash/race/outside-cutoff exactly-once |
| Communication | Existing envelopes/contracts; logical MCP and VPort boundary documentation | Live MCP/VPort registration or server activation |
| Installation | One current RC wheel; separately provisioned jsonschema dependencies; offline operation after installation | Standalone fully offline cold install or all-platform support |
| Lifecycle | Foreman-tested RC package candidate; C04 accepted by exact Judge/Sorcerer evidence | C05 judicial PASS, C06 final PASS, C07 freeze, promotion/release/deployment |

Historical raw SQLite physical-byte observations remain environment-scoped. Logical snapshots include schema and every persisted table; four meaningful mutation controls remain active. See `validation/evidence/C05/ENVIRONMENT_MATRIX.json` for actual RC combinations and `STAGE_ACCEPTANCE_BINDINGS.json` for prior scoped acceptance, not blanket guarantees.
