# Install and use dev.5 locally

Use Python 3.11 or later. Create an isolated environment and install the unified wheel from `releases/wheels/skate_inventory_core-0.3.1.dev5-py3-none-any.whl`. Install its declared jsonschema dependency first if using offline `pip install --no-index --no-deps`. The wheel contains both runtime namespaces and packaged contracts/SQL. Retain older wheels as history; install only the current unified runtime into this environment.

```bash
python -m venv .venv
. .venv/bin/activate
python -m pip install releases/wheels/skate_inventory_core-0.3.1.dev5-py3-none-any.whl
skate-inventory --version
skate-inventory init
skate-inventory
skate-inventory health
skate-inventory --db ./data/skate_inventory.db execute --file command-envelope.json
```

The command file must be one existing command envelope matching packaged contracts. `init` creates only the database schema. Commands requiring device/location/organization reference context must have that context provisioned through the existing trusted-local `skate-registry` compatibility administration; initialization does not provision it. There are no new administrative commands in this CLI.

Module equivalents use `python -m skate_inventory_core`, followed by the same flags and command. For example:

```bash
python -m skate_inventory_core --db ./data/skate_inventory.db run
python -m skate_inventory_core --db ./data/skate_inventory.db health
python -m skate_inventory_core --db ./data/skate_inventory.db execute --file command-envelope.json
```

Global `--db` goes before the command. Default/no-argument run checks deep readiness once and exits. Health/execute require an existing compatible database. Each runtime result is one JSON object; shell exit status distinguishes rejection, conflict, unhealthy runtime and failures. See `C02_BOOT_CLI_CONTRACT.md` for the complete exit matrix. Domain receipt outcomes remain unchanged. This development candidate awaits independent C02 Judge verification.
