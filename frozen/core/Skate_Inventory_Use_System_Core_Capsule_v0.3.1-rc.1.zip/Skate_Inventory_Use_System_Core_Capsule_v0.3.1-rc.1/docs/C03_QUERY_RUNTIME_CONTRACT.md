# C03 public query and runtime-operation contract — dev.6

One `skate_inventory_core.SkateInventoryCore` owns the existing database, contracts, command processor and runtime spine. `execute(envelope)` is unchanged. New `query(name, params)` and `runtime_operation(name, params)` require READY; NEW and SHUTDOWN raise the existing CoreLifecycleError first. Request errors raise exported `CoreRequestError(ValueError)` with stable `.code`. Query misses are data, separate from command REJECTED receipts. Admin operations are explicit trusted-local calls: they do not inherit command-role authorization or provide authenticated identity.

Both facades accept only the fixed names and JSON-compatible object params below. Extra fields, missing required fields, wrong types, whitespace-only required strings, nonfinite numbers, unsupported Python values or unknown names fail closed. Booleans require actual booleans. Params are copied and never mutated. Result data is detached and JSON-compatible; no database/connection/service handles are exposed. Existing direct C01 methods remain compatible.

## Public queries

| Name | Params | Result and miss |
| --- | --- | --- |
| get_pair | required pair_id string | Existing detached Core pair, including components; unknown -> null |
| list_inventory | {} | Existing detached inventory shape and pair/side ordering; empty -> [] |
| find_asset | required identifier string | PAIR, COMPONENT_LABEL or COMPONENT resolution; unknown -> null |
| asset_history | required pair_id string | Stored events ordered by global ledger row sequence; unknown/no events -> [] |
| runtime_status | optional deep boolean, default false | Actual existing health report; no invented readiness |

`find_asset` uses exact input equality, without case folding or whitespace normalization. It follows scan resolution precedence: pair ID, label alias (including inactive), component ID. It does not invoke `scan_asset` and creates no command receipt or event. Result uses the existing scan shape (`resolved_type`, `identifier`, `pair`, optional `component` and `active_label`), plus the stored `alias` record for label matches, including active/retired metadata. Pair objects in resolution are the scan pair shape (no embedded components); get_pair/list_inventory retain their C01 shapes. Current namespace contracts prevent some identifier collisions; precedence is fixed even if legacy data contains one.

History retains original fields, event IDs, actor/device/command/time provenance, correction events and integrity hashes. Stored `payload_json` and `evidence_refs_json` become decoded `payload` and `evidence_refs`. Hash columns become `integrity: {algorithm: SHA-256, event_hash, previous_event_hash}`. Added `ledger_sequence` is the stored SQLite row sequence, not an independent authority or portable global sequence. Results are stored history, not a claim that its chain is verified; use verify_ledger for that. No query writes any logical table/schema, ledger/receipt/idempotency state, or filesystem export.

## Runtime operations

| Name | Params/defaults | Delegation and expected side effects |
| --- | --- | --- |
| health | deep=false | RuntimeSpine.health_report; read-only actual report |
| checkpoint | metadata object optional; create_snapshot=true | create_checkpoint; adds checkpoint and optional snapshot/control digest; original integrity checks |
| replay_check | {} | replay_check; in-memory projection replay, no live writes |
| rebuild_projections | require_clean_replay=true | rebuild_projections; native pre/post checkpoints/snapshots, projection replacement; original integrity/failure behavior |
| verify_ledger | {} | EventLedger.verify_chain; read-only `{ok, first_bad_event_id}` |
| add_evidence | required file_path; optional related_event_id, media_type, storage_ref strings or null | add_evidence; reads input bytes to hash, inserts attachment metadata; original related-event/schema/uniqueness checks |
| export_evidence | {} | Fixed metadata read adapter; no DB/file writes; deterministic evidence metadata object |
| export_recovery | required out_path | Native full-cutoff recovery export; reads source, creates parent directories and writes ZIP; native method may replace an existing non-protected output file |
| restore_recovery | required bundle_path and target_db_path | Native staged full-cutoff restore; reads ZIP and publishes a new database only; source unchanged |

Optional fields are omitted to retain native defaults. Explicit null is accepted only for the three optional add_evidence strings. JSON metadata has string keys and finite numbers. Params schema projections are `contracts/C03_QUERY_REQUEST.schema.json` and `contracts/C03_RUNTIME_REQUEST.schema.json`, generated from the same whitelist validators in `facades.py`.

`export_evidence` returns `format_version`, `kind: EVIDENCE_METADATA_ONLY`, stored attachments sorted by attachment_id, their associated stored events in ledger order, and existing organization/location/device reference snapshot. It contains original hashes, storage refs and event provenance. It excludes attachment bytes and generated timestamps; repeated unchanged state produces identical canonical JSON. References reflect current stored reference context, not historical reconstruction. Metadata export does not read external storage refs or establish their reachability.

Admin results preserve native dictionaries and flags, with JSON conversion of tuples to arrays. Native RegistryError/OSError/SQLite/ZIP exceptions remain direct-call exceptions. A mismatch report is a result with false flags, not fabricated success. Rebuild and checkpoint retain native transaction/partial-work semantics; no new all-or-nothing guarantee is added. `require_clean_replay=false` maps directly to the native parameter and does not override checkpoint integrity checks.

Filesystem path params expand home and resolve against invocation cwd. URI, memory and NUL paths are invalid. Export cannot target the mounted SQLite database, its WAL/SHM/journal paths, or an equivalent symlink/hardlink. Restore additionally rejects any existing target, dangling target symlink, or path equivalent to the live mounted DB before reading the bundle. It requires a separate new target; source data remains unchanged. Native staging and exclusive publication remain in force. There is no overwrite, reset, migration, event-tail merge, concurrent target race guarantee or stronger crash-durability claim. Legacy/tampered/malformed bundles remain rejected by the original repaired recovery implementation.

## Canonical CLI

Existing C02 init/run/health/execute, CLI-only cwd default, no-argument one-shot run, help/version and finally cleanup remain. New commands:

```bash
skate-inventory --db ./data/skate_inventory.db query --file query.json
python -m skate_inventory_core --db ./data/skate_inventory.db runtime --file operation.json
```

Both request files are exactly one UTF-8 JSON object `{"name":"whitelisted_name","params":{...}}`. These are facade requests, not command envelopes. Unknown operation, extra request fields or invalid params are validated before Core construction/database/filesystem operations. Both commands require an existing compatible source DB; neither creates missing DB/directories. Success/report output is one JSON object: `{"command":"query|runtime","db_path":"absolute mounted path","name":"...","result":...}`. A query miss is exit 0 with null/[] data. Execute continues to emit its original receipt wrapper.

| Exit | New-command meaning |
| --- | --- |
| 0 | Actual result without a defined failure flag, including query miss |
| 2 | Invalid request/params/operation/path or protected/existing recovery target; stable CoreRequestError code |
| 5 | health/runtime_status non-HEALTHY, verify_ledger false, replay ledger failure/semantic mismatch/unsupported types, or rebuild semantic mismatch; actual report on stdout |
| 6 | Missing source DB, filesystem/SQLite I/O failure; stable stderr diagnostic |
| 7 | Native RegistryError code, other runtime/ZIP or shutdown failure; sanitized stderr diagnostic |

C02 domain REJECTED/CONFLICT exits remain 3/4. Error shape remains `{"command":...,"db_path":...,"error":{"code":"stable code"}}` on stderr with stdout empty. No traceback or raw private exception details by default. Finally shuts down any constructed Core even when facade execution fails. Filesystem publication and command/domain side effects remain native; caller serialization is required.

## Evidence and disposition

C02 dev.5 semantic PASS accepted by Sorcerer packet 14, bound to Judge receipt `1vAnMUrj_zBCV390SllT-yIvTKFHv2WoI`, SHA-256 `304985d6919680e27f7748ce218106f84cd0993f2680fd0cec2c73d2239e9606`. Judge did not claim unchanged reproduction of all 40 physical-byte C02 assertions. Original C02 suite/evidence remain intact and environment-scoped. A new 40-case semantic companion substitutes all-table/schema snapshots for existing-DB byte comparisons; artifact/unsupported-file integrity checks retain byte/hash comparisons. C02-V01 remains DEFERRED, non-blocking, to C04 for supported-environment portability cleanup. This is not self-closure.

C00-D01 remains resolved within packet 8's independently verified full-export cutoff. C00-D02 remains OPEN pending independent C03 Judge and Sorcerer disposition. C03 FOREMAN implementation/evidence is not an independent PASS. C04-C07 and API/UI/VA00/R03 remain gated. Source, installed subprocesses, namespace/resource/whitelist bindings, logical-state and recovery proof live under validation/evidence/C03.
