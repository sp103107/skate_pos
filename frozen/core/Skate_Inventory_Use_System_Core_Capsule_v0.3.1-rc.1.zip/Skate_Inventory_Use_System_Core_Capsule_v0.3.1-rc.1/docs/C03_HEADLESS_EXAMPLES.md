# C03 headless examples

Install the single unified wheel `releases/wheels/skate_inventory_core-0.3.1.dev6-py3-none-any.whl` into an isolated Python 3.11+ environment with jsonschema dependencies. For offline use after dependencies are installed, use `pip install --no-index --no-deps <wheel>`. Earlier wheels remain historical.

Create the schema with `skate-inventory --db ./data/skate_inventory.db init`. Provision required reference context with the existing trusted-local compatibility administration before executing domain commands. Initialization seeds no organizations/devices/locations/inventory.

Save one request per UTF-8 JSON file:

| File | Content |
| --- | --- |
| inventory.json | `{"name":"list_inventory","params":{}}` |
| lookup.json | `{"name":"find_asset","params":{"identifier":"SKT-0400-L"}}` |
| history.json | `{"name":"asset_history","params":{"pair_id":"SKT-0400"}}` |
| status.json | `{"name":"runtime_status","params":{"deep":true}}` |
| checkpoint.json | `{"name":"checkpoint","params":{"metadata":{"reason":"local checkpoint"}}}` |
| verify.json | `{"name":"verify_ledger","params":{}}` |
| evidence.json | `{"name":"export_evidence","params":{}}` |
| backup.json | `{"name":"export_recovery","params":{"out_path":"./exports/recovery.zip"}}` |
| restore.json | `{"name":"restore_recovery","params":{"bundle_path":"./exports/recovery.zip","target_db_path":"./restored/new.db"}}` |

```bash
skate-inventory --db ./data/skate_inventory.db query --file inventory.json
python -m skate_inventory_core --db ./data/skate_inventory.db query --file lookup.json
skate-inventory --db ./data/skate_inventory.db query --file history.json
skate-inventory --db ./data/skate_inventory.db runtime --file verify.json
skate-inventory --db ./data/skate_inventory.db runtime --file backup.json
python -m skate_inventory_core --db ./data/skate_inventory.db runtime --file restore.json
python -m skate_inventory_core --db ./restored/new.db health
```

Core calls use the same request names/params:

```python
from skate_inventory_core import CoreConfig, SkateInventoryCore
core = SkateInventoryCore(CoreConfig('./data/skate_inventory.db'))
try:
    core.initialize()
    inventory = core.query('list_inventory', {})
    report = core.runtime_operation('verify_ledger', {})
finally:
    core.shutdown()
```

Restore targets must be new and separate from the mounted source. Recovery transports complete ledger/projection/receipt/idempotency metadata within the existing supported cutoff; attachment bytes remain external. Export evidence returns metadata only. Inspect actual result flags and shell exit status; mismatches/ledger failures are nonzero. See C03_QUERY_RUNTIME_CONTRACT.md for strict params, result shapes, side effects and boundaries.
