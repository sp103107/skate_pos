# RC1 quick start — synthetic headless proof

This is Core **0.3.1-rc.1**, distribution **skate-inventory-core==0.3.1rc1**. It is a candidate, not frozen/promoted/released/deployed. Current wheel: `releases/wheels/skate_inventory_core-0.3.1rc1-py3-none-any.whl`. Prior wheels are historical, never alternate current install targets. No UI, API, daemon, MCP server or VPort listener is needed.

## 1. Install in a new environment outside source

Use Python >=3.11 as the declared dependency requirement; only the combinations in `validation/evidence/C05/ENVIRONMENT_MATRIX.json` are demonstrated for this RC. Historical dev.7 Judge Python 3.13 evidence is not an RC test result.

```bash
python3 -m venv /absolute/new/path/skate-rc-env
/absolute/new/path/skate-rc-env/bin/python -m pip install 'jsonschema>=4.21,<5'
/absolute/new/path/skate-rc-env/bin/python -m pip install --no-index --no-deps /absolute/capsule/releases/wheels/skate_inventory_core-0.3.1rc1-py3-none-any.whl
unset PYTHONPATH
/absolute/new/path/skate-rc-env/bin/skate-inventory --version
/absolute/new/path/skate-rc-env/bin/python -m skate_inventory_core --help
```

The dependency-provisioning command normally needs access to an approved package source. For an offline installation, first provision jsonschema and its transitive dependencies from a separately approved cache. The capsule does **not** include third-party dependency artifacts or claim a fully offline cold installation. Core operation after installation uses local files/SQLite and needs no network. Exact tested dependency versions and local provisioning commands are recorded in C05 evidence; building source requires setuptools>=69 and wheel, and regression tests require pytest. No platform-specific installer or dependency redistribution is added.

## 2. Run the safe synthetic fixture

Choose a nonexistent direct child of the system temporary directory named `skate-rc-demo-*`. Do not create that directory first. For example:

```bash
DEMO_ROOT=$(/absolute/new/path/skate-rc-env/bin/python -c 'import pathlib,tempfile,uuid; print(pathlib.Path(tempfile.gettempdir()) / ("skate-rc-demo-"+uuid.uuid4().hex))')
/absolute/new/path/skate-rc-env/bin/python /absolute/capsule/examples/c05_fast_start_demo.py --new-workspace "$DEMO_ROOT"
```

The script refuses existing workspaces, non-temporary paths and a source PYTHONPATH. It uses the current environment's installed console/module, supports no production database override, and preserves `TRANSCRIPT.json`, `DEMO_RESULT.json` and all request envelopes in the new workspace. A successful result prints `status: PASS`. It creates only synthetic rink data. Re-running against the same workspace is deliberately rejected.

The transcript verifies init, explicit/default one-shot run and health; legacy organization/location/device seed; pair/component registration/link/scan/verify/transfer/label/missing/correction; five queries/history; ledger verify/checkpoint/replay/rebuild/evidence metadata; recovery export and new-target restore; original duplicate retry/no extra event; changed-payload conflict and existing-target rejection. It asserts full logical schema/table no-write for queries and rejects an invalid query with exit 2. Canonical regressions additionally cover malformed/legacy/tampered bundles and protected/live targets.

## 3. Inspect or repeat an individual call

The following paths exist only after the synthetic demo. Use its generated envelopes as complete command examples; do not omit actor/reference/idempotency fields or substitute production data.

```bash
/absolute/new/path/skate-rc-env/bin/skate-inventory --db "$DEMO_ROOT/synthetic.db" run
/absolute/new/path/skate-rc-env/bin/python -m skate_inventory_core --db "$DEMO_ROOT/synthetic.db" health
/absolute/new/path/skate-rc-env/bin/skate-inventory --db "$DEMO_ROOT/synthetic.db" query --file "$DEMO_ROOT/requests/list_inventory.json"
/absolute/new/path/skate-rc-env/bin/skate-inventory --db "$DEMO_ROOT/synthetic.db" query --file "$DEMO_ROOT/requests/asset_history.json"
/absolute/new/path/skate-rc-env/bin/skate-inventory --db "$DEMO_ROOT/restored.db" execute --file "$DEMO_ROOT/requests/original_transfer.json"
```

The last call should return DUPLICATE, not create a new transfer. Generated `checkpoint.json`, `replay_check.json`, `rebuild_projections.json`, `export_evidence.json`, `export_recovery.json` and `restore_recovery.json` illustrate exact runtime envelopes. Read them before execution: checkpoint/rebuild/export are explicit administrative side effects; the demonstrated restore target already exists after the demo, so replaying that restore is expected to reject it. Use only a new separate temporary target for another restore. `init` creates schema, not business references. `run` and default boot are one-shot readiness checks, not persistent services. Legacy seed uses `skate-registry add-org/add-location/add-device`, visible in the transcript.

## Boundaries and verification

Domain commands use existing R00/R01 envelopes and role assertions; queries/runtime calls are trusted-local, not authenticated/role-enforced remote operations. Metadata-only evidence export does not transport attachment bytes. Recovery preserves the existing complete-export cutoff, not migration/event-tail merging or stronger crash/race/exactly-once guarantees. Inspect actual JSON flags and exit status: execute rejection 3, conflict 4, semantic/ledger failure 5, request validation 2; no traceback is a success signal by itself.

Read `C05_RELEASE_NOTES.md`, `C05_CAPABILITY_NON_CLAIMS.md`, `C05_ENTRY_MOUNT_MAP.json` and the prepared `C06_FINAL_VALIDATION_CHECKLIST.md`. C05 independent package review is pending; C06 final validation and C07 operator freeze require subsequent explicit gates. Archive state is a precommit acceptance projection of head 19; live relay selects the actual next actor.
