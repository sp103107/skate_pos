# Prepared C06 checklist — not an authorization

C05 package review must return to Sorcerer first. C06 begins only after a subsequent bounded directive and exact operator continue in the declared context. C07 freeze remains a later operator disposition. Do not execute this checklist as an implicit gate transition.

1. Lock exact RC ZIP/provider/checksum, Foreman custody receipt and C05 Judge/Sorcerer disposition; verify full current relay chain/status and current actor.
2. Recover exact bytes; compare SHA/CRC/complete manifest and source-wheel/frozen/history bindings. Reject substitutions, rebuilding or stable reversioning under the old identity.
3. Independently install the locked wheel outside source with no PYTHONPATH or competing distribution; inventory exact dependencies and Python/SQLite/platform; declare unavailable environments NOT_RUN.
4. Reproduce the 218-case canonical suite and applicable focused packaging checks with enumerated IDs/counts, no failures/errors/skips; preserve all earlier evidence without duplicate active collection.
5. Verify actual console/module, both namespaces/25 resources, compile/import, strict/default boot/help/version and meaningful failure exits; network-independent headless operation and documented installation limits.
6. Execute the synthetic demo in a new temporary workspace; check complete workflow, logical no-write/negative controls, recovery cutoff/retry-conflict and invalid/protected targets. Never use operator production data.
7. Reconcile release identity, current target, source lock, entry/mount/envelope/MCP/VPort maps, scoped stage receipts, finding dispositions and precommit snapshot/live-resume distinction. Global release/freeze flags stay false until authorized disposition.
8. Emit independent final-validation receipt against locked bytes, report limitations/debt and return to Sorcerer. No self-promotion or C07 freeze. Explicit operator authorization decides freeze/release actions; different bytes require new exact binding and applicable validation.
