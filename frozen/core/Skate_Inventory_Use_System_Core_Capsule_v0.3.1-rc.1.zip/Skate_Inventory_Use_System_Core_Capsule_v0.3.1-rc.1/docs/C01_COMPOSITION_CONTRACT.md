# C01 Core Composition Contract

Candidate: `Skate Inventory + Use System Core 0.3.1-dev.4`.
Distribution: `skate-inventory-core==0.3.1.dev4`.
This contract documents implementation under relay directive 8, not new governance.

## One composition, one implementation

The sole editable source root is `runtime/source/`. The unified wheel contains
`skate_inventory_core` and the byte-preserved repaired `skate_registry` implementation
(module identity 0.2.1.dev3). The original R01/R02 ZIPs, old wheels and earlier reports
are historical lineage/evidence, not competing editable or install targets.
Do not co-install `skate-inventory-runtime`: both distributions would own `skate_registry`.
Install the unified wheel in `releases/wheels/` into a clean environment.

`SkateInventoryCore(CoreConfig(sqlite_path), contracts=optional_store)` constructs one
Database, one ContractStore, one existing CommandProcessor and one existing RuntimeSpine.
The processor/service and spine/projector share that database/contract ownership;
there is no parallel R01 registry, copied business handler, or new command alias.

| Public surface | Contract | Existing implementation reused |
| --- | --- | --- |
| `CoreConfig(sqlite_path)` | Explicit file path; no default, SQLite URI, in-memory DB, or directory path | `Database` path |
| `initialize()` | Initialize schemas and parent folder; return this Core; repeat while READY is safe | `Database.initialize()` |
| `execute(envelope)` | Return original legacy receipt/error behavior; no command aliases or auth bypass | `CommandProcessor.process()` |
| `health(deep=False)` | Return existing health/replay report | `RuntimeSpine.health_report()` |
| `list_inventory()` | Detached pair/component dictionaries, sorted by existing pair order; no ledger/receipt writes | `export_inventory()` |
| `get_pair(pair_id)` | Detached same public pair shape; unknown ID returns `None`; non-string raises `TypeError` | Existing export surface, selected by exact ID |
| `shutdown()` | Idempotently shut down this facade; does not delete its database | Core lifecycle only |
| `db`, `contracts`, `processor`, `spine` | Guarded existing low-level handles for trusted-local integration/admin operations | Exact composed instances |
| `config`, `state` | Read-only facade metadata | Frozen config; NEW / READY / SHUTDOWN |

## Lifecycle and errors

NEW -> READY -> SHUTDOWN. Runtime methods and guarded low-level properties fail with
`CoreLifecycleError.code == CORE_NOT_INITIALIZED` before initialization and
`CORE_SHUTDOWN` after shutdown. Initialization failures leave NEW so a caller may fix
the cause and retry. SHUTDOWN is terminal for this instance: `initialize()` also raises
CORE_SHUTDOWN. Reopen the same file using a new Core instance and the same CoreConfig.
Separate file configurations have independent state and default contract stores.

The Core owns no long-lived connection pool. Shutdown closes the facade's operation
gate, not independently retained handles or connections obtained from legacy services.
Retained references are trusted-local escape surfaces, not revocable capabilities.
Calls are caller-serialized; thread/process concurrency, authenticated identity,
resource-revocation and network/service lifecycle contracts are not supplied by C01.

All domain command mutations enter through `execute()` and the existing processor.
Existing reference administration, checkpoint/export/restore/rebuild operations retain
their prior trusted-local admin boundaries; C01 does not invent new Core admin methods.
Recovery remains the verified complete-export cutoff from dev.3; no legacy migration,
event-tail merge, or guessed idempotency state is introduced.

The legacy `skate-registry` entry point remains compatible inside the unified wheel.
No new Core CLI, `__main__`, canonical boot adapter, generalized query dispatcher,
or command handler is implemented; those are C02/C03 work.

## Validation and limits

The C01 tests prove fresh initialization, shared instances, envelope registration/scan/
transfer, detached reads with zero persisted-table changes, missing/invalid pair lookup,
repeat init, deterministic lifecycle errors, shutdown/reopen, two-file isolation,
failed-initialization retry, original role/schema/command boundaries and recovery
duplicate/conflict invariants through the Core facade.
Installed proof runs outside the source tree with PYTHONPATH unset, verifies both
namespace origins, all 25 existing contract/SQL resources, and absence of a competing
runtime distribution. Actual collected counts and source-to-wheel hashes are retained.

Foreman testing/building is not independent Judge PASS. C00-D02 remains OPEN: its
composition/minimal reads portion is implemented awaiting Judge, while generalized
query/operation coverage remains C03. C02, API00/UI01/VA00/R03 and promotion/freeze/
release/deployment remain gated. A compiled production candidate is not a release.
