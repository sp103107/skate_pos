# C02 canonical boot and CLI — dev.5

`skate-inventory` and `python -m skate_inventory_core` use the same `skate_inventory_core.cli.main`. The module adapter and setuptools console script call that function. The only mutable runtime tree is `runtime/source`. Both namespaces ship in `skate-inventory-core==0.3.1.dev5`; the repaired registry implementation remains byte unchanged at 0.2.1.dev3. Existing Core lifecycle and explicit CoreConfig remain unchanged.

## Invocation

`[--db PATH] [init | run | health | execute --file COMMAND_ENVELOPE_JSON]`

Global options go before the command. `--help` and `--version` are identical for console/module and do not boot or create files. No arguments, including only `--db PATH`, performs `run`. No abbreviations, aliases, query dispatcher or administrative commands are added. Default CLI path is `./data/skate_inventory.db` under invocation cwd. CoreConfig still requires an explicit path; paths are expanded and made absolute, preserving the established Core path behavior.

- `init`: construct Core, initialize the schema, report READY, shut down. Repeat on a compatible database is idempotent. It does not seed reference data or inventory and does not assert ledger health.
- `run`: construct Core, initialize, call `health(deep=True)`, report real readiness, shut down. This bounded one-shot process exits; it is not a daemon, listener, API or live VPort.
- `health`: require an existing compatible database, initialize the Core facade, call existing deep health, shut down.
- `execute --file`: parse exactly one UTF-8 JSON object, require an existing compatible database, initialize, pass the parsed object unchanged to Core.execute, emit its unchanged receipt, shut down.

Obvious unusable paths are rejected before initialization. Any existing database, including for init/run, receives a read-only preflight against packaged current SQL schema objects; absent/changed required schema objects fail closed. Extra objects are permitted. No reset, repair or migration is attempted. The existing SQL resources are the comparison source, not duplicated schema definitions. This intentionally strict bootstrap compatibility check can reject semantically equivalent but differently declared schemas. SQLite garbage, permission and locking failures report I/O failure. Trusted-local caller serialization remains required; preflight is not a concurrent replacement/race-defense guarantee.

Input parsing occurs before Core construction. Arrays/scalars, multiple objects, duplicate keys, invalid UTF-8, non-JSON numeric constants and floating-point overflow are rejected. Well-formed objects with domain/schema errors still pass unchanged to the original processor and receive its REJECTED receipt. Configuration/parse/rejected/conflict paths are tested to preserve the existing database. An accepted command and supported duplicate semantics may persist original processor control records. No authentication, schema or business behavior is changed.

## Output and exit matrix

Runtime results are one compact JSON object on stdout. Shape: `{"command":"...","db_path":"absolute path","report":{...}}` or `{"command":"execute","db_path":"...","receipt":{original receipt}}`. Help/version use argparse's plain text. Diagnostics are one JSON object on stderr, stdout empty: `{"command":<command or null>,"db_path":<resolved path or null>,"error":{"code":"stable code"}}`. Raw exception details and tracebacks are not diagnostic output. Original domain receipt messages/details are preserved.

| Exit | Meaning | Output |
| --- | --- | --- |
| 0 | Init succeeds; healthy run/health; ACCEPTED or DUPLICATE receipt; help/version | Actual report/receipt, or help/version text |
| 2 | Invalid arguments, database path or JSON envelope | Stable diagnostic code |
| 3 | Domain REJECTED | Original receipt |
| 4 | Domain CONFLICT | Original receipt |
| 5 | Deep health status differs from HEALTHY | Actual health/report, ready false for run |
| 6 | Missing existing database, filesystem/SQLite I/O failure | Stable diagnostic code |
| 7 | Unsupported existing schema, runtime/shutdown failure or unrecognized receipt outcome | Diagnostic or actual unrecognized receipt |

`init.report`: `initialized` (actual READY state), `core_state` before shutdown and `shutdown` after cleanup.

`run.report`: `mode: ONE_SHOT`, actual pre-shutdown `core_state`, `ready` iff READY and deep health is HEALTHY, `components` reporting database initialization, contracts load and construction of processor/spine, identity checks for shared database/contracts, the unchanged deep `health` report and post-cleanup `shutdown`. A constructed component is not a claim that every operation has been exercised. No seed counts or availability are inferred.

`health.report` is exactly the existing deep health object. No fabricated HEALTHY or ACCEPTED result. Core cleanup is in finally whenever construction succeeded, including initialize, health and execute failures; cleanup failure is nonzero. No persistent connection pool is introduced.

## Scope and evidence

C01 accepted by Sorcerer packet 11 on independent Judge receipt `1dowyvrKg8cvHHBC6W5dl3ozzgu9bxtAf` SHA-256 `7a6d882ec99b749481145e669de7e7ac7b4ae6f55734cca1b4ac607af3730e9e`. C00-D01 remains resolved within packet 8's verified full-export cutoff. C00-D02 remains OPEN for C03 generalized query/operation coverage. C02 is FOREMAN-tested and awaits independent Judge verification. C03 and later lanes remain gated.

Tests and source/wheel/frozen/provider bindings are under `validation/evidence/C02`. Installed tests run from outside source with PYTHONPATH unset, using the actual console executable and module subprocesses. A test-only sitecustomize blocks IPv4/IPv6 socket construction and create_connection, proving operational acceptance requires no network after installed dependencies. The hook is not part of the shipped wheel. Source parity uses main directly versus module; installed parity exercises both delivered entry points.
