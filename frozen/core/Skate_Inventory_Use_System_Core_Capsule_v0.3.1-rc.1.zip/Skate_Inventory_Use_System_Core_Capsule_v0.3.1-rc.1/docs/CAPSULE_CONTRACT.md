# Skate Inventory + Use System — Core Capsule Contract v0.3.0

## Purpose

This capsule is the integration boundary for the Skate Inventory + Use System through runtime-hardening stage R02. It binds the human foundation, machine runtime contract, first executable asset registry, and hardened event-ledger/runtime spine into one reproducible package.

## Authority order

1. **F00 Foundation Book** — product intent, physical tagging model, operational concepts.
2. **R00 Core Runtime Contract** — canonical schemas, commands, receipts, states, invariants, and boundaries.
3. **R01 Asset Registry** — first executable implementation of asset identity and custody/ownership/location operations.
4. **R02 Event Ledger + Runtime Spine** — hardened event integrity, replay, recovery, checkpoints, evidence, and health.
5. **Capsule v0.3.0 integration layer** — composition, entry/mount surfaces, child bindings, validation, and next-stage handoff. It may not silently override a frozen child contract.

## Canonical runtime

The canonical executable runtime in this capsule is R02 v0.2.0. Its installable wheel exposes the `skate-registry` console script. The capsule itself does not claim a daemon, web server, or remote transport.

## Entry point law

Any future UI/API/MCP adapter must enter through a defined runtime boundary. Direct UI writes to SQLite are prohibited. New execution surfaces must translate operator intent into validated command/query contracts and must return canonical receipts/errors.

## Mount point law

Foundation, contracts, lineage, runtime distribution, catalogs, UI handoff, and validation evidence are first-class mount surfaces. Frozen artifacts are read-only lineage evidence.

## Communications law

R00 command envelopes and command receipts are canonical. External transports are adapters, not authorities. An MCP or message-bus layer may not invent commands, bypass invariants, or mutate projections directly.

## Evidence law

R02's append-only event spine remains authoritative for runtime history. Projection rebuilds, corrections, checkpoints, evidence attachments, and recovery operations must preserve that lineage.

## Next stages

- **UI00** may now define frontend component families and the frontend/backend mapping matrix against the hardened R02 boundary.
- **R03** remains the next runtime activation stage for checkout/check-in. UI00 may design rental components, but those controls remain non-operational until R03 is implemented and validated.
