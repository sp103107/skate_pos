# Integration record

Core v0.3.0 is the immutable parent. All files from its source tree carry forward except regenerable Python/pytest caches; parent metadata/manifest/README/validation are retained under lineage. Root metadata now honestly records this development integration.

UI00 source carries forward under frontend/UI00_architecture. QTM inventory carries forward under workbench/asset_inventory. QTM roadmap/team/kickoffs are archived under workbench/legacy_qtm as historical planning. QTM external reference ZIPs carry forward under validation/source_bindings/references. The original QTM and UI00 ZIPs remain in Drive release history as provenance only, not competing current product packages. Duplicate expanded QTM copies of the Core/UI00 are not repeated. QTM concept PNG is preserved under frontend/assets.

No runtime source business logic is changed in this setup. runtime/current remains a faithful source projection after cache exclusion. Old validators/manifests may target their original release layout; do not represent a parent validator as validating this integrated version. Current setup evidence separately verifies this snapshot. C00 must reconcile future canonical directory changes and command mappings.
