# Non-Claims

This integration capsule does **not** claim any capability beyond its frozen child artifacts.

- No rental checkout/check-in runtime is active.
- No maintenance policy engine is active.
- No reservation/external-event runtime is active.
- No revenue reconciliation engine is active.
- No frontend or API server is active.
- No HTTP, NATS, MCP, socket, or other external transport is active.
- No VPort is assigned or listening.
- No production deployment, rink installation, device enrollment, or live counter validation has occurred.
- The extracted `runtime/current/` tree is a convenience projection of the frozen R02 package. The frozen R02 ZIP and wheel identities remain authoritative for this capsule bump.
- UI00 is authorized for architecture/mapping design only; it does not activate runtime features that do not yet exist.
