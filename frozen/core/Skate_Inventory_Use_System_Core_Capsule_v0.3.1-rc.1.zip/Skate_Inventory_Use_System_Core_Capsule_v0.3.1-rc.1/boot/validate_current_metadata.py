"""Current RC targeted packaging metadata check; reads actual wheel and packet bindings."""
from pathlib import Path
import configparser,json,zipfile,hashlib
from email.parser import Parser


def validate(root):
    root=Path(root); cap=json.loads((root/'CAPSULE.json').read_text());boot=json.loads((root/'boot/ENTRYPOINTS.json').read_text())
    assert cap['capsule_version']=='0.3.1-rc.1' and (root/'VERSION').read_text().strip()==cap['capsule_version']
    assert cap['canonical_runtime']=='runtime/source'
    assert cap['runtime_entrypoint']==boot['runtime_cli']['command']==boot['canonical_cli']['command']=='skate-inventory'
    assert cap['runtime_python_entrypoint']==boot['runtime_python']['target']==boot['canonical_cli']['target']=='skate_inventory_core.cli:main'
    assert cap['runtime_module_entrypoint']==boot['runtime_module']['command']=='python -m skate_inventory_core'
    assert cap['legacy_runtime_entrypoint']==boot['legacy_cli']['command']=='skate-registry' and boot['legacy_cli']['classification']=='LEGACY_COMPATIBILITY_ENTRYPOINT'
    assert 'pending C02' not in cap['runtime_entrypoint_status']
    assert cap['current_stage']=='C05' and cap['c05_independent_verification']=='PENDING'
    for flag in ['independent_validation_complete','release_freeze','runtime_release_complete','rental_activation_authorized','frontend_activation_authorized']:assert cap[flag] is False
    wheel=root/cap['installable_runtime'];assert cap['installable_runtime']==boot['runtime_cli']['provider']==boot['canonical_cli']['provider']
    with zipfile.ZipFile(wheel) as z:
        assert z.testzip() is None
        prefix='skate_inventory_core-0.3.1rc1.dist-info/'
        meta=Parser().parsestr(z.read(prefix+'METADATA').decode());assert meta['Name']=='skate-inventory-core' and meta['Version']=='0.3.1rc1'
        entry=configparser.ConfigParser();entry.read_string(z.read(prefix+'entry_points.txt').decode())
        assert entry['console_scripts']['skate-inventory']==cap['runtime_python_entrypoint']
        assert entry['console_scripts']['skate-registry']=='skate_registry.cli:main'
        source=root/'runtime/source/src';bound=[]
        for p in sorted(source.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts and p.relative_to(source).parts[0] in ('skate_registry','skate_inventory_core'):
                member=p.relative_to(source).as_posix();assert z.read(member)==p.read_bytes();bound.append(member)
        assert set(bound)=={n for n in z.namelist() if n.startswith(('skate_registry/','skate_inventory_core/'))}
        resources=[n for n in bound if n.endswith(('.sql','.json'))];assert len(resources)==25
        for n in bound:
            if n.endswith('.py'):compile(z.read(n),n,'exec')
        assert '__version__ = "0.3.1rc1"' in z.read('skate_inventory_core/__init__.py').decode()
    stages=json.loads((root/cap['stage_acceptance_bindings']).read_text());packets=json.loads((root/'validation/evidence/C05/inputs/INPUT_RELAY_PACKETS.json').read_text())
    for name,stage in stages.items():
        for field,actor in [('judge_packet','skate-core-judge'),('sorcerer_disposition_packet','skate-core-sorcerer')]:
            b=stage[field];p=packets[b['turn_seq']-1];assert p['packet_id']==b['packet_id'] and p['integrity']['content_hash']==b['sha256'] and p['author']['participant_id']==actor
        judge=packets[stage['judge_packet']['turn_seq']-1]
        assert any(r.get('ref')==stage['judge_receipt']['ref'] and r.get('sha256')==stage['judge_receipt']['sha256'] for r in judge['context_refs'])
        assert stage['state']=='SCOPED_PASS_ACCEPTED'
    for key in ['c00_independent_verification','c00_r01_independent_verification','c01_independent_verification','c02_independent_verification','c03_independent_verification','c04_independent_verification']:assert 'ACCEPTED_PACKET_' in cap[key]
    state=json.loads((root/'communications/relay/CURRENT_STATE.json').read_text());assert state['packet_seq']==state['observed_relay_head']['turn_seq']==19
    assert state['foreman_input_directive']['turn_seq']==state['foreman_live_read_head']==20 and state['snapshot_role']=='ACCEPTANCE_SNAPSHOT_NOT_LIVE_RESUME_STATE'
    assert state['local_build']['prepared_before_own_append'] is True and state['local_build']['own_delivery_packet_or_provider_binding_embedded'] is False
    assert state['observed_relay_head']['packet_id']==packets[18]['packet_id'] and state['foreman_input_directive']['packet_id']==packets[19]['packet_id']
    lock=json.loads((root/'validation/source_bindings/SOURCE_LOCK.json').read_text());assert lock['current_development_parent']['sha256']=='1d7941095c235c552722e404b93c6894512221f82a492158b5731492db6211be'
    assert lock['current_candidate_source']['distribution']==cap['unified_core_distribution']=='skate-inventory-core==0.3.1rc1'
    return {'status':'PASS','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'package_file_count':len(bound),'resource_count':len(resources),'stage_count':len(stages),'release_flags':False,'snapshot_head':19,'input_directive_head':20}


if __name__=='__main__':
    print(json.dumps(validate(Path(__file__).resolve().parents[1]),sort_keys=True))
