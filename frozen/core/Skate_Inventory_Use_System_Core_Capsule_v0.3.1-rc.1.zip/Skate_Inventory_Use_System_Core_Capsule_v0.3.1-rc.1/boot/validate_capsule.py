#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, sys, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]

def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def fail(msg: str):
    print(f'FAIL: {msg}')
    raise SystemExit(1)

capsule = json.loads((ROOT / 'CAPSULE.json').read_text())
bindings = json.loads((ROOT / 'lineage/CHILD_BINDINGS.json').read_text())['bindings']
required = [
    'README.md', 'CAPSULE.json', 'docs/CAPSULE_CONTRACT.md', 'docs/NON_CLAIMS.md',
    'boot/ENTRYPOINTS.json', 'boot/MOUNT_POINTS.json', 'boot/COMMUNICATIONS.json',
    'catalog/CAPABILITY_CATALOG.json', 'ui_handoff/UI00_HANDOFF.json'
]
for rel in required:
    if not (ROOT / rel).is_file():
        fail(f'missing required surface {rel}')

for item in bindings:
    p = ROOT / item['artifact']
    if not p.is_file():
        fail(f'missing bound artifact {item["artifact"]}')
    actual = sha256(p)
    if actual != item['sha256']:
        fail(f'hash mismatch {item["artifact"]}: expected {item["sha256"]}, got {actual}')
    if p.suffix == '.zip':
        with zipfile.ZipFile(p) as zf:
            bad = zf.testzip()
            if bad:
                fail(f'zip integrity failure {p.name}: {bad}')

if capsule.get('rental_activation_authorized') is not False:
    fail('capsule must not authorize rental activation at this stage')
if capsule.get('frontend_activation_authorized') is not False:
    fail('capsule must not claim frontend activation at this stage')

print('PASS: required capsule surfaces present')
print(f'PASS: {len(bindings)} frozen lineage bindings verified')
print('PASS: child ZIP integrity verified')
print('PASS: activation non-claims enforced')
print(f'PASS: capsule {capsule["capsule_id"]} v{capsule["capsule_version"]}')
