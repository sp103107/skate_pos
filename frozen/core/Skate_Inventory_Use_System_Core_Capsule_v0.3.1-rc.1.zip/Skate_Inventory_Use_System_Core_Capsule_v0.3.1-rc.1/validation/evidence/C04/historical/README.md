# Current dev.6 C03 candidate

Canonical install target: releases/wheels/skate_inventory_core-0.3.1.dev6-py3-none-any.whl. Canonical editable source: runtime/source. Five public queries, nine runtime operations and query/runtime CLI delegate existing Core/runtime with fixed validated requests. See docs/C03_HEADLESS_EXAMPLES.md and docs/C03_QUERY_RUNTIME_CONTRACT.md. C02 scoped semantic PASS accepted by Sorcerer packet 14. C03 FOREMAN-tested; independent Judge PENDING. C00-D02 OPEN; C02-V01 DEFERRED to C04. No release, freeze or deployment. Earlier sections, wheels and stage evidence below are historical and do not override these current instructions.

# Current dev.5 C02 candidate

Canonical install target: releases/wheels/skate_inventory_core-0.3.1.dev5-py3-none-any.whl. Canonical editable source: runtime/source. Shared console/module CLI boots the existing Core. See docs/C02_QUICK_START.md and docs/C02_BOOT_CLI_CONTRACT.md. C01 dev.4 PASS accepted by Sorcerer packet 11; C02 FOREMAN-tested, independent Judge PENDING. C00-D02 remains OPEN for C03. No release, freeze or deployment. Earlier sections below, prior wheels and stage evidence are historical and do not override these current instructions.

# Skate Inventory + Use System — one Core development workspace

Version: 0.3.1-dev.1. State: development integration candidate, C00 pending Foreman. This snapshot locks runtime-first work and preserves prior R02 code/wheel plus UI00/QTM planning. It does not compile a new core.

Start with workbench/current_arc/BUILD_LOCK.md, communications/vports/ADAPTER_BINDING.json and communications/relay/CONTINUE_PROTOCOL.md.

Shared relay: https://docs.google.com/document/d/1xvC_tkhaKUY6rcVmbM9wuL4ktTgMscXKgpieYj8tyK4
Session: skate-core-faststart-2026-10-02
Next actor: FOREMAN. Operator types continue in the mounted Foreman context.

One capsule/version line. Frozen R00/R01/R02/parent ZIPs remain exact. Foundation/Control/Data/communications reference archives remain classified reference/candidate where declared. frontend/UI00_architecture and workbench/legacy_qtm contain prior design material; this current arc controls scheduling. Backend/frontend/assets/rental implementation stays gated until C07.

Existing runtime source: runtime/current/R02_Event_Ledger_Runtime_Spine_v0.2.0. Existing prior wheel: runtime/dist/. Proposed unified module/wheel and canonical CLI are C01/C02 targets. Do not install this development snapshot as a newly compiled runtime release.

Drive project: https://drive.google.com/drive/folders/1SjreURPwwGzfjdcY1r6wiI7_sxoDuAPF. Upload supporting files or instructions to 06_TASK_INPUTS; they require scope and source bindings before use. Local CURRENT_STATE is a bootstrap snapshot; live continuation always reads and validates the Doc.

Validation evidence for this setup covers archive/hash/manifest integrity, preserved children, schema-valid genesis and coherent routing. Baseline runtime tests are deliberately assigned to C00; prior test logs remain historical evidence.

## C00 Foreman development evidence

Version 0.3.1-dev.2 adds source reconciliation, source/wheel baseline logs, exact symbol maps, recovery limitation evidence and a bounded C01 proposal. See validation/evidence/C00_SOURCE_RECONCILIATION.md. Independent verification remains pending; unified Core is not compiled. Embedded relay/resume projections precede the final delivery commit; consult the live relay.

## C00-R01 recovery repair candidate

0.3.1-dev.3 adds recovery control-state preservation and staged validation. Install runtime/dist/skate_inventory_runtime-0.2.1.dev3-py3-none-any.whl; 0.2.0 remains historical. See validation/evidence/C00_R01/RECOVERY_COMPATIBILITY.md and test/source evidence. C00-D01 awaits independent Judge; C01 is gated. Historical C00 reports describe dev.2 behavior.

## C01 unified Core development candidate

Version 0.3.1-dev.4 compiles one skate-inventory-core==0.3.1.dev4 wheel in releases/wheels. Canonical editable source: runtime/source. It contains the new skate_inventory_core composition root plus byte-preserved repaired skate_registry implementation. See docs/C01_COMPOSITION_CONTRACT.md and validation/evidence/C01. Earlier runtime wheel/source paths and C00 findings in prior reports are historical evidence, not current install instructions. C01 independent verification remains PENDING; C02 and later lanes remain gated.
