from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;s=w/'c04_work/Skate_Inventory_Use_System_Core_Capsule_v0.3.1-dev.7/runtime/source';logs=w/'c04_logs'
records=[]
for name,source_exe,envname in [('primary','python','c04_primary_env'),('system','/usr/bin/python3.12','c04_system_env')]:
 for mode in ['source','installed']:
  env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
  for key in ['C02_CONSOLE','C03_CONSOLE','C04_CONSOLE','C04_LEGACY']:env.pop(key,None)
  if mode=='source':
   env['PYTHONPATH']=str(s/'src')+':'+str(w/'c00_env/lib/python3.12/site-packages');exe=source_exe;cwd=w
  else:
   env.pop('PYTHONPATH',None);env['C02_TEST_OFFLINE']='1';envroot=w/envname;exe=str(envroot/'bin/python');cwd=w/'c04_installed_checks'
   for key in ['C02_CONSOLE','C03_CONSOLE','C04_CONSOLE']:env[key]=str(envroot/'bin/skate-inventory')
   env['C04_LEGACY']=str(envroot/'bin/skate-registry')
  label=name+'_'+mode
  with (logs/(label+'_collection.log')).open('w') as out:
   c=subprocess.run([exe,'-m','pytest',str(s/'tests'),'--collect-only','-q','-p','no:cacheprovider'],env=env,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  if c.returncode:raise SystemExit('collection failure '+label)
  cmd=[exe,'-m','pytest',str(s/'tests'),'-p','no:cacheprovider','--junitxml='+str(logs/(label+'.xml'))]
  with (logs/(label+'.log')).open('w') as out:r=subprocess.run(cmd,env=env,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  records.append({'label':label,'command':cmd,'PYTHONPATH':env.get('PYTHONPATH'),'cwd':str(cwd),'returncode':r.returncode,'offline_socket_guard':mode=='installed'})
  (logs/'EXECUTION_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n')
  print(label,r.returncode,flush=True)
  if r.returncode:raise SystemExit(1)
