# Skate Inventory Core — dev.7 C04 candidate

One editable runtime: `runtime/source`. One current install target: `releases/wheels/skate_inventory_core-0.3.1.dev7-py3-none-any.whl`, distribution `skate-inventory-core==0.3.1.dev7`. Earlier wheels, frozen archives, stage receipts and historical snapshots are retained as evidence, not current install targets.

Canonical console: `skate-inventory`. Shared Python main: `skate_inventory_core.cli:main`. Module: `python -m skate_inventory_core`. Legacy-compatible reference administration: `skate-registry`.

C04 changes portable acceptance tests and metadata. Production modules match accepted dev.6 byte-for-byte except package version. See `docs/C04_HARDENING_REPORT.md`, `docs/C04_INSTALL_AND_VERIFY.md`, the unchanged C03 facade contract and `validation/evidence/C04` for exact evidence and environment limits.

C00/C00-R01/C01/C02/C03 scoped acceptance is bound to Judge/Sorcerer packets and receipt hashes in `validation/evidence/C04/STAGE_ACCEPTANCE_BINDINGS.json`. C00-D02 is resolved by Sorcerer packet 17. C02-V01 and C03-V01 repairs remain open awaiting independent C04 Judge and Sorcerer disposition. C04 independent verification is pending; global validation/release/freeze flags remain false. C05-C07 and API/UI/VA00/R03 remain gated.

The embedded acceptance snapshot observes head 16 as recorded by directive 17; Foreman's live input head is 17. It is prepared before this candidate's delivery and contains no eventual own provider hash, accepted packet or post-commit revision. The validated live relay is the resume authority.

Dependencies must be installed before offline operation. No daemon/listener, authenticated identity, attachment-byte export, migration, stronger durability/race guarantee or untested environment support is claimed.
