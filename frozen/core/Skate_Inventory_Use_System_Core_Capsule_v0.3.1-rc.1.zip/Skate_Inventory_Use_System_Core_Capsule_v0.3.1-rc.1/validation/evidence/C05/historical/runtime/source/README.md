# Unified Skate Inventory Core 0.3.1.dev7

Install the one unified wheel with its declared `jsonschema>=4.21,<5` dependency using Python >=3.11. Console `skate-inventory` and module `python -m skate_inventory_core` share `skate_inventory_core.cli:main`; `skate-registry` remains legacy-compatible administration. Runtime operations need no network after dependencies are installed. Demonstrated Python/SQLite/platform combinations and NOT_RUN targets are in the outer Capsule `validation/evidence/C04/ENVIRONMENT_MATRIX.json`.

No arguments performs one headless run with cwd-relative `./data/skate_inventory.db`. Commands: init, run, health, execute --file, query --file, runtime --file. Global --db goes before the command. Initialization creates schemas, not reference data/inventory. Health/execute/query/runtime require an existing compatible database. Strict request/result and side-effect contracts remain in outer Capsule docs/C02_BOOT_CLI_CONTRACT.md and docs/C03_QUERY_RUNTIME_CONTRACT.md. See docs/C04_INSTALL_AND_VERIFY.md for current install/check commands.

C04 is test/metadata hardening, not production business-code expansion. Canonical tests contain one portable 40-case C02 suite; retired raw-byte tests remain exact historical evidence in the outer Capsule. Independent C04 Judge verification is pending. No release or freeze.
