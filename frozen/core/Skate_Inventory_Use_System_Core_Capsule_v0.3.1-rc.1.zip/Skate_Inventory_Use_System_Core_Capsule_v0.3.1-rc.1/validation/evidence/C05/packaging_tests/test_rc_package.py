from pathlib import Path
import hashlib,json,subprocess,sys

ROOT=Path(__file__).resolve().parents[4]


def test_single_current_target_and_false_lifecycle_flags():
    cap=json.loads((ROOT/'CAPSULE.json').read_text());boot=json.loads((ROOT/'boot/ENTRYPOINTS.json').read_text())
    assert cap['installable_runtime']==boot['runtime_cli']['provider']==boot['canonical_cli']['provider']==boot['legacy_cli']['provider']
    assert cap['unified_core_distribution']=='skate-inventory-core==0.3.1rc1'
    for flag in ['independent_validation_complete','release_freeze','runtime_release_complete','promotion_complete','deployment_complete']:assert cap[flag] is False
    assert cap['c05_independent_verification']=='PENDING' and cap['c04_independent_verification']=='SCOPED_PASS_DEV7_ACCEPTED_PACKET_20'


def test_preserved_production_and_canonical_tests():
    lock=json.loads((ROOT/'validation/evidence/C05/DEV7_PRODUCTION_LOCK.json').read_text())
    for rel,h in lock['files'].items():
        data=(ROOT/'runtime/source/src'/rel).read_bytes()
        if rel=='skate_inventory_core/__init__.py':data=data.replace(b'0.3.1rc1',b'0.3.1.dev7')
        assert hashlib.sha256(data).hexdigest()==h
    old=ROOT/'validation/evidence/C05/historical/runtime/source/tests/test_c04_hardening.py'
    assert (ROOT/'runtime/source/tests/test_c04_hardening.py').read_bytes().replace(b'0.3.1rc1',b'0.3.1.dev7')==old.read_bytes()


def test_demo_refuses_existing_workspace_without_touching_it(tmp_path):
    marker=tmp_path/'operator_data.txt';marker.write_text('do not touch')
    p=subprocess.run([sys.executable,str(ROOT/'examples/c05_fast_start_demo.py'),'--new-workspace',str(tmp_path)],capture_output=True,text=True)
    assert p.returncode==2 and marker.read_text()=='do not touch' and list(tmp_path.iterdir())==[marker]
