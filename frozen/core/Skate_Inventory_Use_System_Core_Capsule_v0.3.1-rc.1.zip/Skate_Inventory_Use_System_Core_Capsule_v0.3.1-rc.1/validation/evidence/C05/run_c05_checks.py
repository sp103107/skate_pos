from pathlib import Path
import json,os,subprocess,shutil
w=Path.cwd();root=w/'c05_work/Skate_Inventory_Use_System_Core_Capsule_v0.3.1-rc.1';s=root/'runtime/source';logs=w/'c05_logs';logs.mkdir(exist_ok=True);outside=w/'c05_installed_checks';outside.mkdir(exist_ok=True)
records=[]
for name,source_exe in [('primary','python'),('system','/usr/bin/python3.12')]:
 for mode in ['source','installed']:
  env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
  for key in ['C02_CONSOLE','C03_CONSOLE','C04_CONSOLE','C04_LEGACY','C02_TEST_OFFLINE']:env.pop(key,None)
  if mode=='source':
   env['PYTHONPATH']=str(s/'src')+':'+str(w/'c00_env/lib/python3.12/site-packages');exe=source_exe;cwd=w
  else:
   env.pop('PYTHONPATH',None);env['C02_TEST_OFFLINE']='1';eroot=w/f'c05_{name}_env';exe=str(eroot/'bin/python');cwd=outside
   for key in ['C02_CONSOLE','C03_CONSOLE','C04_CONSOLE']:env[key]=str(eroot/'bin/skate-inventory')
   env['C04_LEGACY']=str(eroot/'bin/skate-registry')
  label=name+'_'+mode
  with (logs/(label+'_collection.log')).open('w') as o:
   c=subprocess.run([exe,'-m','pytest',str(s/'tests'),'--collect-only','-o','addopts=','-q','-p','no:cacheprovider'],env=env,cwd=cwd,stdout=o,stderr=subprocess.STDOUT)
  assert c.returncode==0,label
  cmd=[exe,'-m','pytest',str(s/'tests'),'-p','no:cacheprovider','--junitxml='+str(logs/(label+'.xml'))]
  with (logs/(label+'.log')).open('w') as o:p=subprocess.run(cmd,env=env,cwd=cwd,stdout=o,stderr=subprocess.STDOUT)
  records.append({'label':label,'command':cmd,'PYTHONPATH':env.get('PYTHONPATH'),'cwd':str(cwd),'returncode':p.returncode,'offline_socket_guard':mode=='installed'})
  (logs/'EXECUTION_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True)
  assert p.returncode==0,label
