from pathlib import Path
import subprocess,os,json,uuid,shutil
w=Path.cwd();root=w/'c05_work/Skate_Inventory_Use_System_Core_Capsule_v0.3.1-rc.1';outside=w/'c05_installed_checks';logs=w/'c05_logs'
# Reuse the already-scoped installed namespace/resource/import smoke with RC identity.
p=outside/'namespace_check.py';old=(w/'c04_installed_checks/namespace_check.py').read_text();p.write_text(old.replace('c04_primary_env','c05_primary_env').replace('c04_system_env','c05_system_env').replace('0.3.1.dev7','0.3.1rc1'))
env=os.environ.copy();env.pop('PYTHONPATH',None);env.update(C02_TEST_OFFLINE='1',PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
records=[]
for name in ['primary','system']:
 exe=str(w/f'c05_{name}_env/bin/python')
 r=subprocess.run([exe,str(p)],cwd=outside,env=env,capture_output=True,text=True)
 (logs/(name+'_namespace_resources.json')).write_text(r.stdout);assert r.returncode==0,r.stderr
 demo='/tmp/skate-rc-demo-'+name+'-'+uuid.uuid4().hex
 cmd=[exe,str(root/'examples/c05_fast_start_demo.py'),'--new-workspace',demo]
 r=subprocess.run(cmd,cwd=outside,env=env,capture_output=True,text=True)
 (logs/(name+'_demo.log')).write_text(r.stdout+r.stderr)
 records.append({'label':name+'_demo','command':cmd,'returncode':r.returncode,'PYTHONPATH':None,'cwd':str(outside),'network_guard_verified':True})
 (logs/'DEMO_COMMANDS.json').write_text(json.dumps(records,indent=2)+'\n')
 assert r.returncode==0,r.stderr
 for filename in ['TRANSCRIPT.json','DEMO_RESULT.json']:shutil.copy2(Path(demo)/filename,logs/(name+'_'+filename))
 print(name,'installed demo PASS',flush=True)
exe=str(w/'c05_primary_env/bin/python');cmd=[exe,'-m','pytest',str(root/'validation/evidence/C05/packaging_tests'),'-q','-p','no:cacheprovider','--junitxml='+str(logs/'focused_packaging.xml')]
with (logs/'focused_packaging.log').open('w') as o:r=subprocess.run(cmd,cwd=outside,env=env,stdout=o,stderr=subprocess.STDOUT)
assert r.returncode==0,'focused checks';print('focused packaging PASS',flush=True)
