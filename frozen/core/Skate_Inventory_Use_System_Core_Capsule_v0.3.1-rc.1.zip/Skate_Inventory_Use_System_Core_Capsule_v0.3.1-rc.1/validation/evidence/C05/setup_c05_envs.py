from pathlib import Path
import subprocess,shutil,sys
w=Path.cwd();root=w/'c05_work/Skate_Inventory_Use_System_Core_Capsule_v0.3.1-rc.1';logs=w/'c05_logs';logs.mkdir(exist_ok=True)
source=root/'runtime/source';cmd=[sys.executable,'-m','pip','wheel','--no-index','--no-deps','--no-build-isolation',str(source),'-w',str(root/'releases/wheels')]
with (logs/'wheel_build.log').open('w') as o:p=subprocess.run(cmd,stdout=o,stderr=subprocess.STDOUT)
assert p.returncode==0
for name,exe in [('primary',sys.executable),('system','/usr/bin/python3.12')]:
 eroot=w/f'c05_{name}_env';subprocess.run([exe,'-m','venv','--without-pip',str(eroot)],check=True)
 dest=eroot/'lib/python3.12/site-packages';deps=w/'c04_system_env/lib/python3.12/site-packages'
 for p in deps.iterdir():
  if p.name.startswith(('skate','c04_offline')) or p.name in ['__pycache__','sitecustomize.py']:continue
  if p.is_dir():shutil.copytree(p,dest/p.name,dirs_exist_ok=True)
  elif p.is_file():shutil.copy2(p,dest/p.name)
 # A .pth import runs independently of which system sitecustomize is chosen.
 shutil.copy2(w/'c04_system_env/lib/python3.12/site-packages/c04_offline_guard.py',dest/'c05_offline_guard.py')
 (dest/'c05_offline_guard.pth').write_text('import c05_offline_guard\n')
 wheel=root/'releases/wheels/skate_inventory_core-0.3.1rc1-py3-none-any.whl'
 with (logs/(name+'_wheel_install.log')).open('w') as o:p=subprocess.run([str(eroot/'bin/python'),'-m','pip','install','--no-index','--no-deps',str(wheel)],stdout=o,stderr=subprocess.STDOUT)
 assert p.returncode==0,name
 print(name,'clean wheel installed',flush=True)
