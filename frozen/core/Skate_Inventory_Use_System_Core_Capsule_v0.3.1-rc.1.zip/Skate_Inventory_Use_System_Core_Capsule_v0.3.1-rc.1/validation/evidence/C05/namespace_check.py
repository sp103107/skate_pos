from importlib import metadata,resources,import_module
import json,sys,socket,platform,sqlite3,os,zipfile
from pathlib import Path
import skate_inventory_core,skate_registry
from skate_registry.contracts import ContractStore
root=Path(sys.prefix).resolve();assert root.name in ['c05_primary_env','c05_system_env']
assert os.environ.get('PYTHONPATH') is None
for module in [skate_inventory_core,skate_registry]:assert Path(module.__file__).resolve().is_relative_to(root)
assert metadata.version('skate-inventory-core')=='0.3.1rc1'
for name in ['skate-registry','skate-inventory-runtime']:
 try:metadata.version(name);raise AssertionError('competing distribution '+name)
 except metadata.PackageNotFoundError:pass
r=list(resources.files('skate_registry').joinpath('contracts').rglob('*.json'))+list(resources.files('skate_registry').joinpath('sql').glob('*.sql'));assert len(r)==25
for p in r:
 content=p.read_text(encoding='utf-8')
 if p.suffix=='.json':json.loads(content)
ContractStore()
modules=[]
for name in ['skate_inventory_core','skate_registry']:
 for p in Path(import_module(name).__file__).parent.rglob('*.py'):
  compile(p.read_bytes(),str(p),'exec')
  rel=p.relative_to(Path(import_module(name).__file__).parent).with_suffix('')
  module='.'.join((name,*rel.parts))
  if rel.name in ['__init__','__main__']:continue
  import_module(module);modules.append(module)
try:socket.socket();raise AssertionError('offline guard absent')
except AssertionError as ex:assert 'Network forbidden' in str(ex)
print(json.dumps({'status':'PASS','core_origin':skate_inventory_core.__file__,'registry_origin':skate_registry.__file__,'distribution':metadata.version('skate-inventory-core'),'resource_count':len(r),'all_resources_read':True,'all_regular_modules_imported':modules,'console_entry':str(root/'bin/skate-inventory'),'module_entry':'skate_inventory_core.__main__','shared_cli':'skate_inventory_core.cli:main','python_version':sys.version,'sqlite_version':sqlite3.sqlite_version,'platform':platform.platform(),'dependencies':{d.metadata['Name']:d.version for d in sorted(metadata.distributions(),key=lambda d:d.metadata['Name'].lower())},'network_guard_active':True,'PYTHONPATH':os.environ.get('PYTHONPATH'),'competing_distributions':False},indent=2))
