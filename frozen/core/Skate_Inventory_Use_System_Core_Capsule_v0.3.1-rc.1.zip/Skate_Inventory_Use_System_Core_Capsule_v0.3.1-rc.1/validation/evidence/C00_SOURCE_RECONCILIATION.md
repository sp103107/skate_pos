# C00 Source Reconciliation — Foreman

State: C00 reconciliation complete; independent Judge verification pending. Candidate 0.3.1-dev.2 is documentary development evidence, not unified Core compilation, promotion or release.

## Exact inputs and provenance

Operator input was exact `continue` in the mounted FOREMAN context, submitted 2026-10-03T00:36:59-04:00. It opens only C00 under head sequence 2, packet 43c61759-a217-4411-82dd-ba6eb6e12c38, hash d8d507f6792ea2e16703d2d10cc7c6d77ed8d1c231904b6a632a815b6940185b. RC1 Draft 2020-12 schema with formats, RFC8785 JCS, predecessor/reply/concurrency bindings and empty supersession were checked. CURRENT_STATUS agrees with that head. All relay tabs were read (one tab, t.0).

Snapshot provider 1lBeNufmRlI2rzdhS3nLRaUyFcZOXG1nw: effe192afeaffd53ab259598553ef7d062bbbf9bd61d5de07b0237003065ff45. Its complete manifest matches. Sealed v0.3.0 was separately recovered from provider 1p5DpQD4zISuCFXwe-lkfYrP5FqEA_91h: b71b985851b90a79d9d5d667cf890738f4d951da6c2501033d43da3b88e119ea. Embedded R00/R01/R02 archives match the sealed parent exactly. Source classifications remain unchanged; no uploaded pending task input was adopted.

R00: e9844bd40a6e2be7d51f0ce1a2ce1797219c7742d664fdc285ced24b394ad462.
R01: 8e28144fad30ae800eb0ab50f2441f8fdffc464bd127ccc42caa4ed8298615f8.
R02: 2e4eac82877b8d959d39b36b7b0c28fd4d42c0c081434627433f1f423da93d94.
Historical runtime wheel: 4c3db8520378cf5a30cc46fcd8a82cd9c830c654ae3b67cf1963a9acfab0fbc6.

Detailed bindings and equality checks are in C00/SOURCE_VERIFICATION.json. R02 source files equal the frozen child; the wheel's package files/resources equal R02 source. R00 schemas/catalogs also match preserved runtime resources. The prior skate-inventory-runtime wheel remains the only installable runtime.

## Reproduced baseline

An isolated Python venv installed the preserved wheel with no dependency or source rebuild. Runtime/test dependencies were installed separately and copied into the venv; environment versions, commands, cwd and PYTHONPATH are retained in BASELINE_RESULTS.json. The source runs use explicit source paths; the wheel run clears PYTHONPATH and uses the installed package. Pytest plugin autoload and bytecode/cache writes were disabled.

R01 source: 12 passed. R02 source: 18 passed. R02 installed wheel: 18 passed. Each is a separate execution; these are 48 executions, not 48 unique tests. Logs and JUnit XML are included. The preserved capsule validator passes all six child bindings, ZIP integrity and activation boundaries. Installed console-script help resolves the actual 16 CLI commands. R00 is a contract pack with no pytest suite; all its JSON schemas pass Draft202012Validator.check_schema, with contract byte equality checked.

## Findings and compatibility

The baseline is reusable. Commands, queries, classes and boot mapping are in RUNTIME_SURFACE_MAP.md and RUNTIME_SYMBOL_MAP.json. RegistryService has 11 envelope handlers. RuntimeSpine supplies checkpoint, replay, rebuild, health, evidence and recovery operations.

C00-D01 is a reproduced recovery defect: accepted command history/idempotency is omitted from recovery. The diagnostic probe shows two ledger events survive a HEALTHY restore, while both receipts and idempotency tables become empty. Replaying the identical previously accepted transfer command changes DUPLICATE to ACCEPTED and raises event count from 2 to 3. This does not invalidate the reported baseline passes; it limits recovery claims and requires Sorcerer disposition. The probe and exact output are retained. No repair was made.

The Core composition/public query gap is expected planned work, not evidence of a compiled Core. Evidence transport is metadata-only; local administrative paths require a trusted caller and cannot be claimed to enforce authenticated operator authority. Additional risk descriptions and source locators are in DEFECTS_AND_RISKS.json.

## Smallest C01 proposal — not implemented

Introduce one composition root in planned skate_inventory_core, owning a single Database and shared ContractStore, and constructing existing ReferenceDataService, CommandProcessor and RuntimeSpine against them. Reuse skate_registry without renaming its distribution or changing SQL/envelope/ledger semantics. Provide bounded construction/initialization and component access; defer canonical CLI/boot changes to C02 and public query adapters to C03. Keep R00 contract resource loading local and preserve schema_version 0.1.0.

Before implementing, Sorcerer should resolve the intended Core distribution/dependency ownership and disposition C00-D01. Proposed C01 acceptance: clean construction/initialization, shared DB/contracts, real existing service calls, preserved source baseline, and zero activation of rental/API/UI/VA00/R03. No Core wheel build or C01 implementation occurs during C00. C04 should gate recovery retry continuity before making a hardened recovery claim.

## Handoff

One evolving Core candidate retains all prior frozen artifacts and surfaces, adds C00 evidence and updates candidate metadata/manifest. Judge must independently recover exact uploaded bytes and verify source locks, evidence, reports and scope. Foreman supplies execution evidence only, no independent judicial PASS. C01–C07 and later lanes remain gated. The relay delivery packet and its top projection are committed separately after provider byte verification; an archive's embedded resume state is a pre-commit projection, not the live head.
