# Test-only offline guard: no network is available to runtime subprocesses.
import os
if os.environ.get('C02_TEST_OFFLINE') == '1':
 import socket
 _socket = socket.socket
 def denied(*args, **kwargs):
  raise AssertionError('Network forbidden in C02 installed acceptance')
 socket.create_connection = denied
 def local_only(family=socket.AF_INET, *args, **kwargs):
  if family in (socket.AF_INET, socket.AF_INET6): return denied()
  return _socket(family, *args, **kwargs)
 socket.socket = local_only
