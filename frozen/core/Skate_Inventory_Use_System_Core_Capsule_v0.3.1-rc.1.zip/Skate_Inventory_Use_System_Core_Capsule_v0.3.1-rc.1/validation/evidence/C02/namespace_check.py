from importlib import metadata,resources
import json,sys,socket
from pathlib import Path
import skate_inventory_core,skate_registry
from skate_registry.contracts import ContractStore
root=Path(sys.prefix).resolve(); assert root.name=='c02_wheel_env'
for module in [skate_inventory_core,skate_registry]:assert Path(module.__file__).resolve().is_relative_to(root)
assert metadata.version('skate-inventory-core')=='0.3.1.dev5'
try:metadata.version('skate-registry');raise AssertionError('competing distribution')
except metadata.PackageNotFoundError:pass
r=list(resources.files('skate_registry').joinpath('contracts').rglob('*.json'))+list(resources.files('skate_registry').joinpath('sql').glob('*.sql'))
assert len(r)==25
for p in r:
 content=p.read_text(encoding='utf-8')
 if p.suffix=='.json':json.loads(content)
ContractStore()
try:socket.socket();raise AssertionError('offline guard absent')
except AssertionError as ex:assert 'Network forbidden' in str(ex)
print(json.dumps({'core_origin':skate_inventory_core.__file__,'registry_origin':skate_registry.__file__,'distribution':metadata.version('skate-inventory-core'),'registry_implementation_version':skate_registry.__version__,'resource_count':len(r),'all_resources_read':True,'console_entry':str(root/'bin/skate-inventory'),'module_entry':'skate_inventory_core.__main__','both_entrypoints_shared':'skate_inventory_core.cli:main','network_guard_active':True,'PYTHONPATH':__import__('os').environ.get('PYTHONPATH'),'competing_runtime_distribution':False},indent=2))
