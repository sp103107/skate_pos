from pathlib import Path
import os,subprocess,json
w=Path(__file__).parent.resolve();s=w/'c02_work/Skate_Inventory_Use_System_Core_Capsule_v0.3.1-dev.5/runtime/source';r01=w/'source_recovery/Skate_Inventory_Use_System_R01_Asset_Registry_v0.1.0/R01_Asset_Registry_v0.1.0/tests';logs=w/'c02_logs'
runs=[('R01',r01,[]),('R02',s/'tests',['--ignore='+str(s/'tests/test_core_composition.py'),'--ignore='+str(s/'tests/test_core_cli.py')]),('composition',s/'tests/test_core_composition.py',[]),('cli',s/'tests/test_core_cli.py',[])]
for mode in ['source','core_wheel']:
 env=os.environ.copy();env.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1')
 if mode=='source':
  env['PYTHONPATH']=str(s/'src')+':'+str(w/'c00_env/lib/python3.12/site-packages');exe='python';cwd=w
 else:
  env.pop('PYTHONPATH',None);env.update(C02_CONSOLE=str(w/'c02_wheel_env/bin/skate-inventory'),C02_TEST_OFFLINE='1');exe=str(w/'c02_wheel_env/bin/python');cwd=w/'c02_installed_checks'
 for name,target,extra in runs:
  cmd=[exe,'-m','pytest',str(target),*extra,'-p','no:cacheprovider','--junitxml='+str(logs/(name+'_'+mode+'.xml'))]
  with (logs/(name+'_'+mode+'.log')).open('w') as out:r=subprocess.run(cmd,env=env,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
  print(name,mode,r.returncode,flush=True)
  if r.returncode:raise SystemExit(1)
