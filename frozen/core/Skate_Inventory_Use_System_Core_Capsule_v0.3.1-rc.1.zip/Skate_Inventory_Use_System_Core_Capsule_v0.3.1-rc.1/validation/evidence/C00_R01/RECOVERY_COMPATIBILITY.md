# C00-R01 Recovery Compatibility

Candidate 0.3.1-dev.3 repairs C00-D01 within the prior R02 namespace and CLI.
Install `runtime/dist/skate_inventory_runtime-0.2.1.dev3-py3-none-any.whl`.
The original 0.2.0 wheel and frozen R00/R01/R02 archives remain byte-identical historical evidence.
The current source directory retains its inherited v0.2.0 path; distribution metadata and package __version__ are 0.2.1.dev3. No unified skate_inventory_core wheel exists.

## Recovery boundary

Recovery format `0.2.1.dev3` adds controls.json with complete command_receipts and idempotency_records, retaining insertion order, receipt JSON and original receipt links. Export starts BEGIN IMMEDIATE before any read, taking a single consistent full ledger/control/reference/projection cutoff. A prior standalone checkpoint does not select an older export boundary. Checkpoints now record control digest and receipt/idempotency counts alongside existing ledger/projection fields.

Only the complete exported cutoff is supported. There is no event-tail merge or reconstruction of missing keys from events; commands accepted after export are outside this guarantee. Rebuilding projections preserves command control state. Identical retries within the cutoff remain DUPLICATE with the original event IDs and result; changed payloads retain IDEMPOTENCY_CONFLICT behavior. Error receipts that the existing processor never persists are outside stored control state.

## Restore and compatibility

Old 0.2.0 bundles are explicitly unsupported: they lack the full control boundary. They fail with LEDGER_INTEGRITY_ERROR and an unsupported-version explanation, with no published writable database. Missing, duplicate, unexpected/path archive members, incomplete manifests, malformed data, checksum mismatches, inconsistent metadata/control links, foreign-key violations, invalid ledgers and projection/replay drift also fail closed.

Restore reads only the exact flat archive member set, creates a private staged database on the target filesystem, validates receipt schemas, idempotency/original receipt linkage, accepted event ownership/coverage, duplicate result linkage, cutoff counts/digests, foreign keys and deep ledger/replay health. Only then it creates a validation checkpoint and publishes a self-contained SQLite backup through an exclusive hard link. Invalid input does not create a target or its missing parent. Existing targets are never overwritten, including racing target publication. This uses a filesystem supporting same-volume hard links; unsupported publication raises an OS error without a HEALTHY result. No crash durability or cross-filesystem publication guarantee is claimed.

Checksums are corruption/inconsistency detection, not authenticated signatures. A trusted local operator remains required. Evidence attachments remain metadata/reference-only; their original external bytes are not packaged by recovery.

## Foreman verification

Original runtime regression: FAIL as expected (retry ACCEPTED instead of DUPLICATE).
R01 suite: 12 PASS. Repaired R02 source suite: 38 PASS (18 existing + 20 new cases). Repaired installed wheel suite: 38 PASS. The same source/resources are in the installed wheel. New checks include exact 7 receipt/6 idempotency cutoff counts, original linkage equality, event/projection stability, changed-payload conflict, 14 invalid-input cases including rehashed semantic corruption, old-checkpoint/new-export boundary, rebuild determinism, existing target preservation, empty cutoff, and concurrent writer exclusion during export. The duplicate-member test intentionally triggers a zipfile warning while constructing malicious input.

C00-D01 is REPAIR_IMPLEMENTED_AWAITING_JUDGE, not closed. Independent Judge verification and Sorcerer disposition remain required. C01 and API/UI/VA00/R03 stay gated. No promotion, operator freeze, release or deployment.
