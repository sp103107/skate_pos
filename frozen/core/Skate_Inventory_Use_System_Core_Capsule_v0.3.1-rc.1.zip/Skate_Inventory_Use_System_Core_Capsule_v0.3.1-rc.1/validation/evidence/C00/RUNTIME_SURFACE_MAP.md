# C00 Runtime Surface Map

Existing package: `skate-inventory-runtime==0.2.0`; import namespace `skate_registry`; console script `skate-registry = skate_registry.cli:main`. No `skate_inventory_core` module/wheel exists.

| Envelope command | Existing handler |
| --- | --- |
| `link_pair` | `skate_registry.service.RegistryService._cmd_link_pair` |
| `mark_component_missing` | `skate_registry.service.RegistryService._cmd_mark_component_missing` |
| `record_correction` | `skate_registry.service.RegistryService._cmd_record_correction` |
| `register_component` | `skate_registry.service.RegistryService._cmd_register_component` |
| `register_pair` | `skate_registry.service.RegistryService._cmd_register_pair` |
| `replace_label` | `skate_registry.service.RegistryService._cmd_replace_label` |
| `scan_asset` | `skate_registry.service.RegistryService._cmd_scan_asset` |
| `transfer_custody` | `skate_registry.service.RegistryService._cmd_transfer_custody` |
| `transfer_location` | `skate_registry.service.RegistryService._cmd_transfer_location` |
| `transfer_ownership` | `skate_registry.service.RegistryService._cmd_transfer_ownership` |
| `verify_inventory` | `skate_registry.service.RegistryService._cmd_verify_inventory` |

Dispatch remains `CommandProcessor.process(envelope)` → schema/payload validation → role/reference checks → duplicate/conflict handling → `RegistryService.execute(conn,envelope)` → ledger event and receipt transaction. Handler names are internal, not new public aliases.

| CLI subcommand | Existing symbol |
| --- | --- |
| `init-db` | `Database.initialize` |
| `add-org` | `ReferenceDataService.add_organization` |
| `add-location` | `ReferenceDataService.add_location` |
| `add-device` | `ReferenceDataService.add_device` |
| `run-command` | `CommandProcessor.process` |
| `scan` | `CommandProcessor.process (scan_asset)` |
| `import-csv` | `inventory_io.import_inventory_csv` |
| `export-json` | `inventory_io.export_inventory` |
| `verify-ledger` | `EventLedger.verify_chain` |
| `checkpoint` | `RuntimeSpine.create_checkpoint` |
| `health` | `RuntimeSpine.health_report` |
| `replay-check` | `RuntimeSpine.replay_check` |
| `rebuild-projections` | `RuntimeSpine.rebuild_projections` |
| `add-evidence` | `RuntimeSpine.add_evidence` |
| `export-recovery` | `RuntimeSpine.export_recovery_bundle` |
| `restore-recovery` | `RuntimeSpine.restore_recovery_bundle` |

Queries: `scan_asset` is an envelope command with a persisted receipt but no ledger event; `export_inventory(db)` returns pairs with components. `projection_snapshot`, `reference_snapshot`, `health_report`, and `replay_check` expose current state. There is no existing public `query_pair`/`query_inventory` API. `_pair_dict` and `_component_dict` are internal service helpers.

Evidence registration hashes an existing file and records its reference; it does not copy the evidence bytes. Recovery ZIP contains references, projection, ledger, evidence metadata, corrections, bundle metadata and checksums. Receipts/idempotency and original attachment files are not included.

`Database.initialize()` executes R01 and R02 SQL idempotently. `ProjectionRebuilder.replay_into` covers the declared inventory events plus corrections; unsupported later event types remain outside scope. SQLite transactions and trigger/hash protections are local process/database evidence, not authenticated operator identity or a live VPort.
