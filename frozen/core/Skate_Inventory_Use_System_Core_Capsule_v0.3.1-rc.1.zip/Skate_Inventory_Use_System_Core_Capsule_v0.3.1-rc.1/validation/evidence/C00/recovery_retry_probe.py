from pathlib import Path
import tempfile, json, uuid
from skate_registry.db import Database
from skate_registry.reference_data import ReferenceDataService
from skate_registry.processor import CommandProcessor
from skate_registry.spine import RuntimeSpine
from skate_registry.util import utc_now

def envelope(name, payload):
    return dict(command_id=str(uuid.uuid4()), schema_version='0.1.0', command_name=name,
                requested_at=utc_now(), actor_id='c00-probe', actor_role='OWNER_ADMIN',
                device_id='DEV-COUNTER', location_id='LOC-RINK', idempotency_key=str(uuid.uuid4()),
                payload=payload, offline_created=False)

def counts(db):
    with db.connect() as conn:
        return {t: conn.execute('SELECT COUNT(*) FROM '+t).fetchone()[0]
                for t in ['asset_events','command_receipts','idempotency_records']}

with tempfile.TemporaryDirectory() as td:
    root=Path(td); db=Database(root/'source.sqlite'); db.initialize(); ref=ReferenceDataService(db)
    ref.add_organization(dict(org_id='ORG-OWNER',name='Owner',org_type='ASSET_OWNER'))
    ref.add_location(dict(location_id='LOC-RINK',name='Rink',location_type='RINK'))
    ref.add_device(dict(device_id='DEV-COUNTER',name='Counter',device_type='COUNTER_TABLET'))
    p=CommandProcessor(db)
    first=p.process(envelope('register_pair',{'pair':dict(pair_id='SKT-0001',owner_org_id='ORG-OWNER',size_system='US_MENS',size_value='8',category='HOCKEY',home_location_id='LOC-RINK',current_location_id='LOC-RINK',custodian_org_id='ORG-OWNER')}))
    assert first['status']=='ACCEPTED',first
    command=envelope('transfer_location',dict(pair_id='SKT-0001',to_location_id='LOC-RINK'))
    assert p.process(command)['status']=='ACCEPTED'
    before=counts(db); pre_retry=p.process(command); assert pre_retry['status']=='DUPLICATE'
    spine=RuntimeSpine(db); spine.export_recovery_bundle(root/'recovery.zip')
    restore=RuntimeSpine.restore_recovery_bundle(root/'recovery.zip',root/'restored.sqlite')
    dest=Database(root/'restored.sqlite'); restored_counts=counts(dest)
    after_retry=CommandProcessor(dest).process(command); after_counts=counts(dest)
    print(json.dumps(dict(probe='recovery_retry_continuity',before=before,pre_restore_retry=pre_retry['status'],restore=restore,restored_counts=restored_counts,post_restore_retry=after_retry['status'],after_retry_counts=after_counts),indent=2))
    assert after_retry['status']=='ACCEPTED'
    assert after_counts['asset_events']==before['asset_events']+1
