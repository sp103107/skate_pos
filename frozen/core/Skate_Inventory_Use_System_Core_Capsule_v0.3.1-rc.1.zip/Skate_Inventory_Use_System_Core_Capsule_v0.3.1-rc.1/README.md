# Skate Inventory Core 0.3.1-rc.1 — fast-start candidate

Start with [C05_QUICK_START](docs/C05_QUICK_START.md). Current install target: `releases/wheels/skate_inventory_core-0.3.1rc1-py3-none-any.whl`; sole editable runtime source: `runtime/source`. All prior wheels, source snapshots and stage receipts remain immutable historical evidence and are not current install instructions. Earlier C00-C04 documentation is historical stage material, not current installation guidance.

Accepted dev.7 runtime behavior is unchanged except package version. C04 PASS and C02-V01/C03-V01 resolution are bound to Judge packet 19 / Sorcerer packet 20 and the recovered Judge receipt in `validation/evidence/C05`. This RC's C05 independent package verification is **PENDING**. It is not a release, promotion, freeze or deployment; C06/C07 and API/UI/VA00/R03/rental/live-server lanes remain gated.

Canonical console: `skate-inventory`; module: `python -m skate_inventory_core`; shared main: `skate_inventory_core.cli:main`. Legacy `skate-registry` provides explicit trusted-local reference administration. No network/UI/API service is needed. Provision jsonschema dependencies separately; offline operation does not mean a standalone fully offline cold installation.

The synthetic demo accepts only a new temporary `skate-rc-demo-*` workspace, never a production DB path. Release notes, capability/non-claims matrix, entry/mount map, environment/acceptance evidence and prepared C06 checklist document precise scope. Packaged relay state projects head 19 before append; actual input/read head is 20, and the validated live relay remains resume authority. Own eventual provider checksum/packet is intentionally absent from sealed bytes and recorded externally in sidecars/receipt/relay.
