# Runtime-first project lock

Operator-approved scope: one evolving Core Capsule, one product version line, one release history. R00, R01 and R02 are internal layers of the eventual single executable core. Existing archives remain exact historical evidence.

C00 reconciles existing sources before choosing implementation. C01 composes one runtime object; C02 provides a canonical boot/CLI; C03 unifies commands, queries, and recovery; C04 proves a clean offline installation; C05 packages a candidate; C06 obtains independent Judge verification; C07 records the operator freeze disposition.

The proposed `skate_inventory_core` module and wheel are targets, not existing binaries. Do not rename the prior R02 wheel or represent it as a compiled v0.3.1 core. Preserve existing command identifiers until source reconciliation proves their mappings.

UI00/QTM planning is preserved inside this core tree. API00, UI01, VA00 and R03 implementation remain gated through C07. Old next-stage fields and old QTM kickoff packets are historical planning, superseded by this project-specific runtime-first scheduling decision only. They retain their source classifications; no Foundation law is changed.

Law/contracts, implementation, and evidence/work remain distinct. Working source edits occur locally; Drive holds durable source inputs, exact candidate/release snapshots, completion records, and the team relay. A future database-native canonical workspace needs a separate explicit migration; this handoff does not claim one.

Sorcerer owns architecture and bounded directives. Foreman builds and reports evidence. Judge independently verifies and never repairs the candidate it judges. Stephen retains promotion, release, deployment and final freeze authority. Validation alone does not release a product.
