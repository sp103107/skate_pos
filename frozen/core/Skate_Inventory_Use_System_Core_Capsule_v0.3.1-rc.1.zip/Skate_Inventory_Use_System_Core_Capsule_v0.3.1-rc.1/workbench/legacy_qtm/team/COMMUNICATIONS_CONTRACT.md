# AoS Skate QTM Team Communications Contract

**Session:** `skate-qtm-2026-10-01`  
**Relay reference:** `agent_relay_protocol_v0.1.0_rc1`  
**Authority:** human operator only.  
**Registry claim:** none. Logical VPorts are workbench addresses only.

## Fast-path rules

1. One lane owns each file/surface at a time.
2. All cross-lane handoffs are packetized with source hashes, changed paths, validation evidence, blockers, and declared next actor.
3. Compare-and-append must reject stale predecessor state; no silent overwrite.
4. Frontend never writes SQLite. API00 may translate transport only; it may not redefine command/query meaning.
5. R03 rental work is parallel but remains non-activating until independent verification passes.
6. Visual assets are presentation artifacts; they never imply capability activation.
7. Merge order for the first marketable build: `API00 -> UI01 shell -> inventory workflows -> evidence/admin -> kiosk hardening -> acceptance`.

## Packet minimum

Every handoff packet records: session_id, lane/role, base source hashes, changed paths, claims, tests, unresolved defects, capability-state changes (if any), requested reviewer, and next task.
