# API00 Local Adapter Kickoff

Create a small local web adapter for the existing Python R02 runtime. Prefer a minimal HTTP JSON surface suitable for a local kiosk/web frontend.

Required first surfaces: health, inventory list/summary, asset detail/history, command submission, receipt lookup, ledger verification, replay/checkpoint/rebuild/recovery, evidence attachment.

The adapter is transport only. It cannot write SQLite directly or alter R00/R02 command semantics.
