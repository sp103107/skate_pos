# R03 Rental Runtime Kickoff

Separate runtime lane. Implement rental checkout/checkin semantics and projections behind existing R00 contracts, with deterministic receipts, idempotency, version conflict behavior, maintenance interaction gates, and tests. UI rental activation is forbidden until independent verification passes.
