# UI01 Frontend Implementation Kickoff

Build the first marketable operator UI against UI00 v0.1.0. Use React + TypeScript + Vite (versions pinned at implementation time). Start with AppShell, Dashboard, Scan, Inventory, Asset Detail, Registration, Verification, Runtime Health, Audit, Recovery, Offline Queue.

**Hard boundary:** no direct SQLite access. All mutations use command envelopes through API00/CommandProcessor. Rental/Maintenance/Reservation/Revenue controls remain gated until their runtime lanes are independently verified.
