# Quick-to-Market Build Order

## Marketable v1 target
A local-first rink counter application that can identify skates, register and verify inventory, inspect asset history, transfer location/custody where authorized, replace labels, mark missing components, audit receipts/events, and export recovery evidence. Rental buttons may be visible as gated previews, but live rental is not part of the first green build until R03 lands.

## Critical path
1. Asset masters + design tokens.
2. API00 local adapter.
3. UI01 shell + scan/inventory/detail.
4. Inventory mutation flows.
5. Audit/health/recovery/evidence.
6. Offline draft UX and scanner/kiosk hardening.
7. Acceptance pack.
8. Merge R03 and activate rental only after verifier gate.
