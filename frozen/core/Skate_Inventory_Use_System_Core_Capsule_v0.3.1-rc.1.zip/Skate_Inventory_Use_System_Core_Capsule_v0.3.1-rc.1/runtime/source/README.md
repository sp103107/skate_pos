# Skate Inventory Core 0.3.1rc1 candidate

One-shot local headless composition of the repaired registry, contracts and runtime spine. Canonical console `skate-inventory`; module `python -m skate_inventory_core`; both share `skate_inventory_core.cli:main`. Legacy trusted-local reference administration is `skate-registry`.

Python requirement: >=3.11. Runtime dependency: jsonschema>=4.21,<5. Provision it and its transitive dependencies before a `--no-index --no-deps` wheel installation. This wheel does not bundle third-party dependency artifacts. Offline operation after provisioning is distinct from a fully offline cold installation.

From the capsule, follow `docs/C05_QUICK_START.md`; the synthetic runbook uses a new temporary workspace only. Five public queries and nine runtime operations preserve accepted dev.7 behavior. No API/UI/network service, authenticated identity, rental activation or live MCP/VPort listener is added. RC is not a release, promotion, freeze or deployment. Final C06/C07 gates remain separate.

The evidence export format's existing `0.3.1.dev6` marker is a preserved protocol-format identifier, not the distribution version. Attachment-byte transport, migration and stronger crash/race guarantees remain out of scope.
