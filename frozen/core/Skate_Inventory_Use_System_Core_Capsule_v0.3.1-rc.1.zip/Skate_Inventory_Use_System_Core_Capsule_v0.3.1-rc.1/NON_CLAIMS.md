This setup does not compile the unified core.
RC1 is a task-scoped communications reference, not universally admitted communications law.
No independent validation, promotion, release, deployment, VPort registry activation or autonomous wake is claimed.
No new core wheel, live API, frontend, rental, socket, MCP server, registry registration, autonomous chat wake or production readiness is established.
