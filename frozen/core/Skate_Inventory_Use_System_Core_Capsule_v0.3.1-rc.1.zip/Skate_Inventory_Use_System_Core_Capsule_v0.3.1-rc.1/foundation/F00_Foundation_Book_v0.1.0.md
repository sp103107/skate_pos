# Skate Inventory + Use System
## Foundation Book v0.1.0

**Status:** Foundation / design authority for implementation  
**Purpose:** Define the canonical asset, rental, maintenance, custody, and reconciliation model before building the core runtime and frontend.  
**Deployment target:** Ice-rink rental counter first; multi-venue capable by design.  
**Operating principle:** Physical skate inventory and digital state must remain reconcilable from an append-only event record.

---

## 1. Executive Summary

The Skate Inventory + Use System is a purpose-built asset lifecycle platform for rental skates. It is designed to answer, at any moment:

- What skates do we own?
- Where is each skate now?
- Which left and right skates belong together?
- Which pairs are available, rented, reserved, missing, quarantined, or retired?
- How many rental cycles and estimated hours has each pair accumulated?
- When was each blade last sharpened?
- Which skates need routine cleaning, deep cleaning, sharpening, inspection, or repair?
- Which skates are reserved for external events such as Providence College dates?
- Which venue or operator had custody of the skates at a given time?
- What rental activity occurred during a shift or event?
- If a revenue-sharing arrangement exists, what activity should be reconciled between the asset owner and rink operator?

The system is intentionally built around **asset identity, custody, use events, and maintenance evidence**, not around a cash register. Payment integration can be added later without changing the core asset model.

The first implementation should be simple enough to run at a skate counter from a phone, tablet, or inexpensive barcode scanner, while remaining rigorous enough to support multiple venues, external-event reservations, and independent ownership of the skate fleet.

---

## 2. Foundation Decisions

### 2.1 The pair is the commercial asset; each skate is a physical component

A rental customer rents a pair, but left and right skates can become separated. Therefore the data model must represent both levels.

**Pair ID example:** `SKT-0123`  
**Left component:** `SKT-0123-L`  
**Right component:** `SKT-0123-R`

Both physical skates display the same large human-readable pair number (`0123`) while their machine-readable codes identify the individual component.

This enables:

- mismatch detection;
- single-skate loss tracking;
- component-specific repair records;
- replacement of one side without destroying historical pair identity;
- future analysis of asymmetric wear.

### 2.2 QR + Code 128 + human-readable ID

Each component label should carry:

1. a QR code for phones/tablets;
2. a Code 128 barcode for inexpensive handheld scanners;
3. a large short human-readable pair number;
4. `L` or `R` component designation.

The scanner payload should remain short and stable. Recommended payload:

`SKT-0123-L`

The software resolves the identifier to the full asset record. The label should not encode mutable fields such as size, condition, location, or maintenance state.

### 2.3 Use durable polyester asset labels, not ordinary decorative vinyl

Waterproof vinyl can work for a prototype, but the production tag should use a **high-tack polyester asset-label stock with a protective laminate or durable printed topcoat**. Skate inventory is exposed to moisture, condensation, cleaning chemicals, cold/warm cycling, abrasion, and repeated handling.

3M documents polyester label materials with strong moisture, chemical, abrasion, and temperature resistance and adhesives intended for plastics and metals. This is a better material class for a production deployment than ordinary craft vinyl.

**Recommended physical strategy:**

- primary component label on a cleaned, low-flex, low-contact surface;
- secondary backup label inside the boot/tongue area where it does not contact the customer;
- round corners on labels to reduce edge lifting;
- clean with an appropriate surface cleaner before application and allow adhesive dwell time;
- pilot several placements before committing the entire fleet.

If a skate's exterior plastics reject adhesive or the label is repeatedly damaged, the fallback should be a small mechanically retained asset tag placed where it cannot contact the blade, interfere with laces, create a snag hazard, or touch the skater.

### 2.4 Ownership and custody are separate concepts

The system must never infer ownership from physical location.

Example:

- **Owner:** Avarachi Ventures LLC
- **Custodian:** rink operator
- **Current location:** Veterans Memorial Ice Rink
- **Authorized use:** public skate rentals

Moving skates to another venue changes custody/location, not ownership.

Any ownership transfer requires an explicit ownership-transfer event and supporting evidence reference.

### 2.5 Canonical history is event based

Every meaningful change creates an immutable event. Current state is a projection of those events.

Examples:

- registered;
- assigned to pair;
- checked out;
- checked in;
- inspected;
- quick-cleaned;
- deep-cleaned;
- sharpened;
- damaged;
- repaired;
- quarantined;
- reserved;
- transferred between locations;
- lost;
- found;
- retired.

The system may maintain fast current-state tables, but those tables are derived operational state. The event ledger is the durable history.

---

## 3. Goals

### 3.1 Operational goals

The system shall:

- make counter rental checkout/check-in fast enough for a public-skate rush;
- identify every physical skate and pair;
- maintain an accurate use count;
- create a maintenance queue automatically;
- support manual condition flags by counter staff;
- reserve inventory for external events;
- show inventory availability by size;
- expose pair mismatches immediately;
- provide a shift/event reconciliation record;
- preserve ownership and custody history;
- operate through intermittent connectivity;
- provide a clear audit trail for both owner and venue.

### 3.2 Business goals

The system should support agreements where:

- the asset owner supplies and maintains the skates;
- the rink provides counter staff and customer handling;
- revenue is split according to configurable terms;
- the rink can demonstrate exactly how many rentals occurred;
- the owner can independently inspect usage and maintenance status.

### 3.3 Non-goals for the first runtime

The first release does not need to:

- replace the rink's entire POS system;
- store sensitive customer profiles;
- process credit cards;
- automatically determine blade sharpness from sensors;
- predict failures using machine learning;
- use RFID/UHF infrastructure;
- perform payroll or general accounting.

Those can be added later without changing the foundation.

---

## 4. Physical Identification Standard

### 4.1 Label contents

Each skate receives a component label such as:

**Pair:** 0123  
**Side:** L  
**QR:** `SKT-0123-L`  
**Code 128:** `SKT-0123-L`

A matching right skate uses `SKT-0123-R`.

### 4.2 Recommended label size

Initial pilot target:

- QR area: approximately 20-25 mm square where surface area permits;
- human pair number large enough to read from counter distance;
- barcode sized for reliable scanner capture rather than minimum possible size.

The exact production dimensions should be validated on actual skates before bulk printing.

### 4.3 Label-placement pilot

Do not label all 100+ pairs at once.

Pilot 10 pairs across common boot types and sizes. Test at least two candidate locations for 2-3 weeks of real use. Record:

- scan success;
- edge lifting;
- abrasion;
- cleaning resistance;
- customer contact;
- readability when wet;
- whether labels interfere with storage racks.

The winning placement becomes the deployment standard.

### 4.4 Future optional identifiers

NFC can be added later for tap-based maintenance or inventory audits. It should supplement, not replace, visible QR/barcode/human identification because visible identifiers remain usable when electronics fail.

---

## 5. Canonical Asset Model

### 5.1 Pair record

Required fields:

- `pair_id`
- `owner_org_id`
- `size_system`
- `size_value`
- `brand`
- `model`
- `category` (`hockey`, `figure`, `other`)
- `acquisition_date`
- `acquisition_source`
- `acquisition_cost` (optional operational field)
- `ownership_evidence_ref`
- `home_location_id`
- `current_location_id`
- `custodian_org_id`
- `availability_state`
- `maintenance_state`
- `lifecycle_state`
- `total_rental_cycles`
- `estimated_use_minutes`
- `last_inventory_verified_at`
- `created_at`
- `updated_at`

### 5.2 Component record

Each pair has left and right component records.

Required fields:

- `component_id`
- `pair_id`
- `side`
- `label_identifier`
- `serial_or_manufacturer_id` if available
- `blade_type`
- `component_condition`
- `replacement_history`
- `current_location_id`
- `last_seen_at`

### 5.3 Availability state

Availability answers: **Can this pair be rented right now?**

Canonical values:

- `AVAILABLE`
- `RENTED`
- `RESERVED`
- `IN_MAINTENANCE`
- `QUARANTINED`
- `MISSING_COMPONENT`
- `LOST`
- `RETIRED`

### 5.4 Maintenance state

Maintenance is separate from availability so the system can represent nuance.

Canonical values:

- `OK`
- `INSPECTION_DUE`
- `QUICK_CLEAN_DUE`
- `DEEP_CLEAN_DUE`
- `SHARPEN_DUE`
- `REPAIR_DUE`
- `OUT_OF_SERVICE`

Multiple maintenance flags may exist simultaneously even when one summarized state is displayed.

### 5.5 Lifecycle state

- `ACTIVE`
- `SEASONAL_STORAGE`
- `TRANSFERRED`
- `RETIRED`
- `DISPOSED`

---

## 6. Event Ledger

### 6.1 Event envelope

Every event should contain:

- `event_id`
- `event_type`
- `occurred_at`
- `recorded_at`
- `actor_id`
- `actor_role`
- `location_id`
- `pair_id`
- optional `component_id`
- `rental_session_id` if relevant
- `before_state`
- `after_state`
- `reason_code`
- `notes`
- optional evidence attachment references
- `device_id`
- `offline_sequence`
- integrity hash / receipt field

### 6.2 Core event types

**Inventory**

- `ASSET_REGISTERED`
- `COMPONENT_REGISTERED`
- `PAIR_LINKED`
- `INVENTORY_VERIFIED`
- `LOCATION_TRANSFERRED`
- `CUSTODY_TRANSFERRED`
- `OWNERSHIP_TRANSFERRED`

**Rental**

- `RENTAL_CHECKOUT`
- `RENTAL_CHECKIN`
- `RENTAL_VOIDED`
- `RENTAL_EXTENSION`

**Maintenance**

- `CONDITION_INSPECTED`
- `QUICK_CLEAN_COMPLETED`
- `DEEP_CLEAN_COMPLETED`
- `SHARPEN_COMPLETED`
- `REPAIR_OPENED`
- `REPAIR_COMPLETED`
- `QUARANTINED`
- `RETURNED_TO_SERVICE`

**Exception**

- `DAMAGE_REPORTED`
- `COMPONENT_MISSING`
- `ASSET_LOST`
- `ASSET_FOUND`
- `LABEL_REPLACED`
- `PAIR_MISMATCH_DETECTED`

**Reservation**

- `RESERVATION_CREATED`
- `RESERVATION_RELEASED`
- `EXTERNAL_EVENT_PACKED`
- `EXTERNAL_EVENT_RETURNED`

---

## 7. Rental Workflow

### 7.1 Counter checkout

Minimum flow:

1. Staff selects or scans rental session/event.
2. Staff scans either skate of the pair.
3. System resolves pair and verifies both components are present.
4. System displays size and maintenance status.
5. If available, checkout is confirmed.
6. `RENTAL_CHECKOUT` event is appended.
7. Pair becomes `RENTED`.

Target operational time: a few seconds per pair after staff is trained.

### 7.2 Counter return

1. Scan pair/component.
2. System resolves active rental.
3. Staff performs a rapid condition check.
4. Staff selects one-tap flags if needed: wet/needs drying; odor/cleaning; blade issue; lace issue; structural damage; or missing mate.
5. System appends `RENTAL_CHECKIN`.
6. Use counters increment.
7. Maintenance rules run.
8. Pair either returns to `AVAILABLE` or enters maintenance/quarantine.

### 7.3 Rush mode

During heavy public-skate intake, the frontend must allow:

- scan -> confirm -> next;
- minimal typing;
- large touch targets;
- queueing while offline;
- audible/visual success and error feedback;
- immediate warning for wrong/mismatched pair.

### 7.4 Anonymous session model

The system does not need customer PII for ordinary rentals.

A rental can reference:

- event/session;
- transaction/ticket number;
- pair IDs;
- checkout/check-in times;
- rental price or revenue bucket if enabled.

Customer identity is optional and should not be required for the MVP.

---

## 8. Maintenance Model

### 8.1 Maintenance should be condition + usage driven

Do not hardcode one universal sharpening or cleaning interval. Ice conditions, blade steel, customer weight, walking on non-ice surfaces, rental duration, and skate model all affect wear.

The runtime shall use configurable policy thresholds combined with staff inspection.

### 8.2 Suggested initial policy profile

These are **starting configuration values for field testing**, not claims of universal skate-maintenance standards.

- quick wipe/dry inspection: every return;
- deep-clean review: after configurable rental-cycle threshold or visible/odor condition flag;
- sharpening review: after configurable rental-cycle/use-time threshold or any edge-condition flag;
- mandatory inspection: after impact/damage flag;
- immediate quarantine: cracked holder, loose blade, structural boot damage, missing fastener, or any safety concern.

The first deployment should collect data for several weeks and then tune thresholds from observed wear.

### 8.3 Sharpening record

A sharpening event should capture:

- pair/component;
- date/time;
- operator;
- machine (`Sparx`, manual machine, external vendor);
- hollow/radius setting if tracked;
- ring/wheel identifier if useful;
- pre-condition;
- post-condition;
- notes;
- rentals/use since prior sharpening.

### 8.4 Cleaning record

Cleaning events should distinguish:

- routine dry/wipe;
- disinfect/sanitize;
- deep clean;
- deodorization;
- lace/liner replacement;
- drying hold.

The maintenance dashboard should show due items by urgency rather than forcing staff to inspect every pair manually.

---

## 9. Reservation and External-Event Model

The owner must be able to reserve inventory for external commitments such as Providence College events.

A reservation includes:

- reservation ID;
- event name;
- venue;
- date/time window;
- required quantity by size/category;
- reserved pair IDs or dynamic allocation rule;
- pack-out deadline;
- transport status;
- return/reconciliation status.

Reserved skates cannot be checked out at the rink once the configured lockout window begins.

The system should support a **pack manifest** generated by scanning pairs into bins/racks before departure and scanning them back on return.

---

## 10. Multi-Party Custody and Revenue Reconciliation

### 10.1 Roles in a shared operating model

The system must support:

- **Asset Owner:** owns skates and maintenance responsibility.
- **Venue Operator:** provides physical location and potentially staff.
- **Counter Operator:** performs rental transactions.
- **Maintenance Operator:** sharpens/cleans/repairs.

One organization may fill multiple roles.

### 10.2 Revenue-sharing support

If revenue sharing is enabled, each rental transaction may include:

- gross rental amount;
- taxes/fees if applicable;
- owner share;
- venue share;
- operator share;
- payment method reference;
- reconciliation status.

The foundation must support percentage, fixed-per-rental, fixed-period, or hybrid agreements.

### 10.3 Reconciliation principle

The asset ledger and the financial ledger are related but separate.

A missing payment record must never erase a rental-use event. Likewise, a payment record must not imply a particular skate was rented unless the rental event exists.

This separation makes it possible for the owner and rink to independently reconcile activity.

---

## 11. Roles and Permissions

### Owner Admin

Can:

- register/retire assets;
- view all history;
- configure maintenance policies;
- create external reservations;
- approve ownership transfers;
- view reconciliation reports.

### Rink Manager

Can:

- view inventory assigned to venue;
- view rental activity;
- manage venue staff;
- view maintenance availability;
- view reconciliation reports allowed by agreement.

Cannot transfer ownership.

### Counter Staff

Can:

- check out/check in;
- report damage;
- flag maintenance;
- view size/availability.

Cannot modify ownership, acquisition history, or erase events.

### Maintenance Tech

Can:

- inspect;
- clean;
- sharpen;
- repair;
- quarantine/return to service within policy.

### Auditor / Read Only

Can view event history and reports without operational write permission.

---

## 12. Offline-First Operating Requirement

A rink counter cannot stop working because Wi-Fi drops.

The first runtime should therefore support:

- local device queue for scan events;
- deterministic local event IDs;
- visible offline indicator;
- local validation against the most recent asset state;
- ordered synchronization when connectivity returns;
- conflict handling when the same pair was changed on multiple devices;
- immutable sync receipts.

For a single-rink MVP, a local server or one authoritative counter device can dramatically reduce conflict complexity while retaining future sync compatibility.

---

## 13. Core Runtime Boundary

The future core runtime owns:

- asset registry;
- pair/component relationships;
- event validation;
- event append;
- state projection;
- rental workflow rules;
- maintenance policy evaluation;
- reservation conflicts;
- custody and ownership rules;
- reconciliation calculations;
- user/role authorization;
- audit receipts;
- import/export.

The frontend must not independently invent state transitions. It requests actions; the runtime validates and records them.

---

## 14. Frontend Boundary

The future frontend should contain five principal surfaces.

### Counter

- Scan checkout
- Scan return
- Size availability
- Active rentals
- Exception flagging

### Inventory

- Search/scan asset
- Pair/component status
- Size/category inventory
- Location/custody
- Missing/mismatch queue

### Maintenance

- Due queue
- Sharpen workflow
- Cleaning workflow
- Damage/repair workflow
- Return-to-service validation

### Reservations / External Events

- Event reservation
- Size allocation
- Pack manifest
- Departure/return scan

### Reconciliation / Audit

- Rentals by event/shift/date
- Usage by pair
- Revenue split if enabled
- Maintenance costs/use
- Custody history
- Exportable audit record

---

## 15. Core Data Objects

Minimum canonical objects:

- `Organization`
- `Location`
- `User`
- `RoleGrant`
- `SkatePair`
- `SkateComponent`
- `AssetLabel`
- `AssetEvent`
- `RentalSession`
- `RentalTransaction`
- `MaintenancePolicy`
- `MaintenanceTask`
- `Reservation`
- `ExternalEventManifest`
- `CustodyAssignment`
- `RevenueAgreement`
- `ReconciliationPeriod`
- `EvidenceAttachment`

---

## 16. Example API Intent Surface

These are conceptual runtime commands, not final HTTP paths.

- `register_pair`
- `scan_asset`
- `checkout_pair`
- `checkin_pair`
- `flag_condition`
- `complete_cleaning`
- `complete_sharpening`
- `open_repair`
- `complete_repair`
- `quarantine_pair`
- `return_pair_to_service`
- `reserve_inventory`
- `pack_external_event`
- `receive_external_event`
- `transfer_custody`
- `verify_inventory`
- `open_reconciliation_period`
- `close_reconciliation_period`

Every command returns a receipt containing event IDs and resulting state.

---

## 17. Reporting Requirements

The system should produce:

- Current inventory by size
- Available inventory by size
- Missing/mismatched pairs
- Rentals today / this session
- Rentals by pair
- Most-used / least-used pairs
- Pairs due for sharpening
- Pairs due for deep cleaning
- Open repair/quarantine list
- External-event reservation conflicts
- Inventory ownership/custody report
- End-of-shift rental report
- Revenue-share reconciliation report
- Asset lifecycle history

A useful future metric is **cost per rental cycle**: acquisition + maintenance + repairs divided by completed rental cycles.

---

## 18. Evidence and Audit Requirements

The system must never silently rewrite history.

Corrections occur through compensating events, for example:

- erroneous checkout -> `RENTAL_VOIDED`;
- incorrect pair link -> unlink/relink event with reason;
- ownership correction -> authorized ownership event with evidence reference.

Important events should retain:

- actor;
- timestamp;
- device;
- reason;
- prior and resulting state;
- optional image/document evidence;
- integrity receipt.

Exports should be possible as JSONL/CSV for independent verification.

---

## 19. Security and Privacy

The system should minimize customer data.

For ordinary skate rentals, the system can operate with no customer name at all. If customer contact information is later added for deposits or long-term rentals, it must be isolated from the core asset history and protected by role-based access.

Minimum requirements:

- authenticated staff identities;
- least-privilege roles;
- immutable audit events;
- encrypted transport when networked;
- protected administrative actions;
- backups of the canonical database/event store;
- export/restore validation.

---

## 20. Failure and Recovery

### Scanner failure

Allow manual entry of human-readable asset ID.

### Label damage

Use backup interior label or inventory lookup; create `LABEL_REPLACED` event.

### Wrong pair detected

System blocks normal checkout until mismatch is resolved or an authorized exception is recorded.

### Offline operation

Queue validated events locally and sync later.

### Device lost

Server-side permissions can revoke device credentials; unsynced local data should be protected where practical.

### Database failure

Restore from backup and replay append-only events to reconstruct current state.

---

## 21. MVP Acceptance Criteria

The first usable release is complete when it can:

1. Register at least 125 pairs with left/right components.
2. Print/export identifiers for durable physical labels.
3. Scan either component and resolve the correct pair.
4. Check pairs out and in from a phone/tablet or barcode scanner.
5. Increment use counts automatically.
6. Flag damage/maintenance during return.
7. Generate sharpening and deep-clean queues from configurable rules.
8. Reserve inventory for external event dates.
9. Show availability by size in real time.
10. Produce an append-only event history for each pair.
11. Produce a shift/session rental report.
12. Track owner, custodian, and location separately.
13. Continue basic counter operations during a temporary network outage.
14. Export inventory and event data in open formats.

---

## 22. Implementation Sequence

### Stage F00 - Foundation Book

**Current stage.** Locks terminology, identities, states, events, workflows, ownership/custody model, and implementation boundaries.

### Stage R00 - Core Runtime Contract

Create canonical schemas, command contracts, event envelope, state transitions, and database model.

### Stage R01 - Asset Registry

Implement organizations, locations, pairs, components, label identities, ownership, custody, and inventory import.

### Stage R02 - Event Ledger + Projection

Append-only events, receipts, projections, correction model, export/replay.

### Stage R03 - Rental Runtime

Checkout/check-in, session management, size availability, use counters, exceptions.

### Stage R04 - Maintenance Runtime

Policies, queues, inspections, cleaning, sharpening, repair, quarantine.

### Stage R05 - Reservations / External Events

Providence College and other event reservations, pack manifests, return reconciliation.

### Stage R06 - Revenue Reconciliation

Optional shared-rental accounting and configurable revenue agreements.

### Stage R07 - Offline + Sync Hardening

Device identity, offline queue, sync receipts, conflict handling.

### Stage UI00 - Frontend Foundation

Responsive design system, scan interaction, counter keyboard/scanner behavior, role-aware navigation.

### Stage UI01 - Counter

Rush-mode checkout/return and availability.

### Stage UI02 - Inventory + Maintenance

Asset lookup, queues, pair history, maintenance workflows.

### Stage UI03 - Reservations + Reconciliation

External-event manifests, reports, settlement views.

---

## 23. Recommended First Physical Pilot

Before runtime development is considered complete, run a physical identity pilot:

1. Select 10 representative pairs.
2. Assign pair/component IDs.
3. Print high-tack polyester QR/Code-128 labels with human-readable pair numbers.
4. Apply primary + backup tags.
5. Simulate 30-50 checkout/check-in cycles.
6. Wet/dry skates repeatedly.
7. Perform normal cleaning.
8. Test scanning under rink lighting with a phone and inexpensive scanner.
9. Record label failures and scan failures.
10. Lock the winning label stock and placement as a deployment standard.

The software and the physical identifier are one system. A perfect database with unreliable labels is not a usable rental platform.

---

## 24. Foundation Conclusions

The Skate Inventory + Use System should be built around five invariants:

1. **Every physical skate has durable identity.**
2. **Ownership is never inferred from location or custody.**
3. **Every use and maintenance action leaves an event receipt.**
4. **Availability and maintenance are separate states.**
5. **The counter remains operational even when connectivity is imperfect.**

This foundation is sufficient to begin the Core Runtime Contract without redesigning the conceptual model.

---

## Appendix A - Initial Physical Label Recommendation

For production, prefer durable polyester asset-label stock with high-performance adhesive over ordinary craft vinyl. 3M documents polyester label materials intended for demanding applications with moisture, chemical, abrasion, and temperature resistance, and adhesive options suitable for plastics and metals.

Relevant manufacturer references reviewed during foundation design:

- 3M Computer-Imprintable Polyester Label Material 7883 - durable polyester, moisture/chemical resistance, adhesion to HSE and LSE plastics.
- 3M Sheet/Screen Label Material 7220SA - polyester facestock, strong environmental resistance, and adhesive performance through humidity and hot/cold cycling.

The exact production material must still be tested against the actual skate boot/holder substrates before fleet-wide deployment.

## Appendix B - Identifier Example

**Pair record:** `SKT-0123`  
**Left skate:** `SKT-0123-L`  
**Right skate:** `SKT-0123-R`

Human-facing label:

`0123  L`  
`[QR] [CODE128]`

The runtime resolves identifiers to mutable metadata. The physical label never needs to be replaced merely because size metadata, condition, custodian, or location changes.
