# Skate Inventory + Use System
## R00 Core Runtime Contract v0.1.0

**Status:** CONTRACT_FROZEN_CANDIDATE  
**Parent authority:** Foundation Book v0.1.0  
**Purpose:** Freeze the implementation contract for R01-R07 before runtime code is written.  
**Scope:** Canonical entities, identifiers, command and event envelopes, state transitions, invariants, persistence model, receipts, concurrency, offline semantics, and acceptance gates.

---

## 1. Authority and Normative Order

R00 translates the Foundation Book into implementation constraints. When R00 artifacts disagree, the normative order is:

1. `catalogs/invariants.json`;
2. JSON Schemas under `schemas/`;
3. state/command/event catalogs under `catalogs/`;
4. this human-readable contract;
5. `sql/reference_sqlite.sql`, which is a reference physical projection rather than the ultimate semantic authority.

R00 does not activate a backend, deploy an API, create a production database, or authorize silent changes to Foundation concepts. Any material semantic change requires a versioned R00 revision.

## 2. Runtime Principles

The core runtime SHALL be authoritative for validation and durable state change. Frontends, scanners, imports, and offline clients request commands; they do not directly mutate canonical state.

The runtime SHALL preserve these design properties:

- event history is append-only;
- current operational state is rebuildable;
- ownership and custody are distinct;
- pair and component identity are both first-class;
- physical use events and financial events remain separate;
- ordinary rentals do not require customer PII;
- offline-created activity is accepted only through deterministic validation and conflict handling;
- all mutating commands return a durable receipt or a deterministic rejection.

## 3. Canonical Identifiers

| Object | Format | Example |
|---|---|---|
| Pair | `SKT-####` | `SKT-0123` |
| Component | `SKT-####-L/R` | `SKT-0123-L` |
| Organization | `ORG-*` | `ORG-AVARACHI` |
| Location | `LOC-*` | `LOC-CVMR` |
| User | `USR-*` | `USR-COUNTER01` |
| Device | `DEV-*` | `DEV-CVMR-TABLET1` |
| Event/command/receipt | UUID | UUIDv4 recommended |

Identifiers are stable references. Mutable attributes such as size, location, condition, owner display name, and maintenance state SHALL NOT be encoded into the physical QR/barcode payload.

## 4. Canonical Data Objects

R00 freezes these implementation objects:

- Organization
- Location
- Device
- SkatePair
- SkateComponent
- AssetEvent
- RentalSession
- MaintenancePolicy
- Reservation
- CustodyAssignment
- RevenueAgreement
- EvidenceAttachment
- CommandEnvelope
- CommandReceipt

The JSON Schemas in `schemas/` define their minimum machine-readable shapes. R01+ may add implementation-only fields that do not weaken or contradict R00, but interoperable exports SHALL preserve the canonical fields.

## 5. Skate Pair Contract

A SkatePair is the commercial rental asset. A normal ACTIVE pair contains one active left component and one active right component. Components remain independently addressable so the runtime can detect missing mates, track component-specific repair, and replace one side without destroying pair history.

The pair projection includes:

- owner organization;
- current custodian;
- home and current location;
- size/category metadata;
- availability state;
- maintenance summary + flags;
- lifecycle state;
- use counters;
- verification timestamps;
- optimistic projection version.

## 6. State Machines

### 6.1 Availability

Canonical states: `AVAILABLE, RENTED, RESERVED, IN_MAINTENANCE, QUARANTINED, MISSING_COMPONENT, LOST, RETIRED`.

Normal checkout is allowed only from `AVAILABLE`. A reservation may temporarily hold a pair in `RESERVED`. Safety or completeness conditions move a pair to maintenance, quarantine, missing, lost, or retired states.

The machine-readable allowed transitions and guards are in `catalogs/state_transitions.json`. A transition missing from that catalog is forbidden unless R00 is versioned.

### 6.2 Maintenance

Canonical summary states: `OK, INSPECTION_DUE, QUICK_CLEAN_DUE, DEEP_CLEAN_DUE, SHARPEN_DUE, REPAIR_DUE, OUT_OF_SERVICE`. Multiple maintenance flags may coexist. The summary state is a projection used for display and blocking rules; individual flags preserve nuance.

### 6.3 Lifecycle

Canonical states: `ACTIVE, SEASONAL_STORAGE, TRANSFERRED, RETIRED, DISPOSED`. `DISPOSED` is terminal. `RETIRED` may transition only to `DISPOSED`; it does not return to rentable service.

## 7. Runtime Invariants

- **INV-001** — Every ACTIVE pair has exactly one active L component and one active R component except during an explicitly recorded replacement or missing-component condition.
- **INV-002** — A component may belong to at most one active pair at a time.
- **INV-003** — Ownership never changes from location, custody, rental, reservation, or maintenance events.
- **INV-004** — Ownership changes only through transfer_ownership with OWNER_ADMIN authorization and an OWNERSHIP_TRANSFERRED event.
- **INV-005** — At most one active rental exists for a pair.
- **INV-006** — A normal checkout requires AVAILABLE state, a complete pair, no blocking maintenance, and no reservation lockout conflict.
- **INV-007** — A check-in must resolve an active rental unless an authorized correction workflow is used.
- **INV-008** — Events are append-only. Corrections use compensating events; durable events are never silently edited or deleted.
- **INV-009** — A financial record never creates, deletes, or substitutes for a physical rental-use event.
- **INV-010** — A payment record does not imply a particular skate was used unless a rental event exists.
- **INV-011** — A pair in QUARANTINED, MISSING_COMPONENT, LOST, RETIRED, or blocking maintenance state cannot be normally checked out.
- **INV-012** — The same command idempotency key must produce the same logical outcome or a deterministic conflict.
- **INV-013** — recorded_at is assigned by the authoritative runtime; occurred_at may precede recorded_at for offline events but must not be used to rewrite prior durable history.
- **INV-014** — Current state projections must be rebuildable from the event ledger plus immutable reference/master data.
- **INV-015** — Counter operation must not require customer PII for ordinary rentals.

These invariants are validation law. R01-R07 implementations SHALL test them explicitly rather than relying on frontend behavior.

## 8. Command Contract

Every state-changing request enters through a CommandEnvelope containing command identity, schema version, actor, role, device, location, idempotency key, optional expected projection version, and command payload.

Core commands are enumerated in `catalogs/commands.json`. The command surface includes registration, checkout/check-in, maintenance, reservation, transfer, exception, and reconciliation actions.

A command MAY emit one or more events. A command MUST NOT claim success until its durable event append and projection transaction succeed.

### 8.1 Idempotency

The same logical command retried with the same idempotency key SHALL return the original receipt. Reusing an idempotency key for materially different input SHALL return `IDEMPOTENCY_CONFLICT`.

### 8.2 Optimistic concurrency

Mutating pair commands SHOULD carry `expected_pair_version`. If the authoritative projection changed after the client read it, the runtime SHALL reject with `VERSION_CONFLICT` rather than overwriting newer state. Rush-mode clients may omit the field only where the command has deterministic server-side conflict checks.

## 9. Event Envelope

Every durable mutation emits at least one AssetEvent. The event envelope captures:

- immutable event ID and schema version;
- event type;
- occurred and recorded timestamps;
- actor/role, device, and location;
- relevant pair/component/session references;
- originating command;
- reason/notes/evidence references;
- offline sequence;
- event-specific payload;
- SHA-256 integrity hash and optional previous-event hash.

`recorded_at` is assigned by the authoritative runtime. `occurred_at` may represent an earlier offline action but SHALL never authorize back-dated rewriting of history.

## 10. Event Catalog

R00 freezes 34 initial event types across inventory, rental, maintenance, exception, reservation, and reconciliation domains. Their names are enumerated in `catalogs/event_types.json` and the AssetEvent schema.

Corrections are compensating events. Durable events are never silently edited to make history appear cleaner.

## 11. Checkout Validation

`checkout_pair` SHALL reject unless all of the following are true:

1. the pair exists;
2. the pair projection is `AVAILABLE`;
3. exactly one active left and right component are present;
4. no blocking maintenance condition exists;
5. no active rental already exists;
6. no confirmed reservation lockout conflicts with the checkout;
7. the actor role is authorized at the location;
8. any optimistic version supplied by the client still matches.

Success appends `RENTAL_CHECKOUT`, creates/updates active-rental projection, and changes availability to `RENTED` in the same transaction.

## 12. Check-in Validation

`checkin_pair` SHALL resolve an active rental, append `RENTAL_CHECKIN`, increment rental/use counters exactly once, process return-condition flags, evaluate the active maintenance policy, and place the pair into `AVAILABLE`, `IN_MAINTENANCE`, `QUARANTINED`, or another valid resulting state.

A duplicate check-in retry SHALL be idempotent. A genuine second check-in for an already closed rental SHALL be rejected or routed through correction logic; it must not increment use twice.

## 13. Ownership, Custody, and Location

These are separate axes:

- **ownership** answers who owns the asset;
- **custody** answers who is responsible for possession/operation;
- **location** answers where the asset is physically assigned/observed.

Location and custody transfers SHALL NOT modify owner fields. Ownership transfer requires a separately authorized command, evidence reference where available, and `OWNERSHIP_TRANSFERRED` event.

## 14. Reservations and External Events

A confirmed reservation may allocate explicit pair IDs or size/category quantities. When the lockout window begins, reserved inventory SHALL no longer be available for conflicting rink checkout.

Pack-out and return use scan manifests. The return process SHALL reconcile expected versus returned components and surface missing/mismatched inventory without deleting the reservation history.

## 15. Maintenance Runtime Contract

Maintenance policy is configuration, not hard-coded universal truth. Policies may create due flags from rental cycles, estimated use minutes, calendar time, or condition flags.

Safety-relevant defects SHALL be able to block availability immediately regardless of ordinary thresholds. Completing sharpening/cleaning/repair creates events with operator, device, time, and relevant maintenance details.

## 16. Offline Semantics

Offline clients may create commands with deterministic IDs, idempotency keys, local sequence numbers, and captured occurred timestamps. They SHALL NOT directly append authoritative events.

On synchronization, the server validates the command against authoritative state. Outcomes are:

- `ACCEPTED` — durable events appended;
- `DUPLICATE` — prior receipt returned;
- `CONFLICT` — state changed incompatibly;
- `REJECTED` — validation/authorization failed.

A client must visibly surface unresolved conflicts. It may not silently discard them.

## 17. Receipts

Every mutating command returns a CommandReceipt containing command ID, status, recorded time, emitted event IDs, resulting state summary, and any error. Receipts are suitable for local audit, sync acknowledgement, and operator troubleshooting.

## 18. Error Contract

Machine-readable error codes are frozen in `catalogs/error_codes.json`. Human messages may evolve; stable error codes may not be repurposed to mean a different condition within the same major contract version.

## 19. Reference Persistence Model

`sql/reference_sqlite.sql` supplies a runnable reference relational projection for the first single-rink deployment. It intentionally separates:

- master/reference data;
- current operational projections;
- append-only asset events;
- rentals;
- reservations;
- maintenance tasks;
- custody;
- revenue agreements;
- evidence attachments.

The reference schema is validated by executing it against an in-memory SQLite database during package build. A later PostgreSQL projection is permitted if it preserves R00 semantics.

## 20. Transaction Boundary

A successful mutating command SHOULD complete in one authoritative transaction:

1. authenticate/authorize actor;
2. validate command schema + business guards;
3. verify idempotency/concurrency;
4. append event(s);
5. update current-state projection(s);
6. persist receipt;
7. commit;
8. return receipt.

No client-visible success may be returned before commit.

## 21. Projection and Replay

The current-state tables are operational projections. The runtime SHALL provide a testable replay mechanism capable of rebuilding pair state, use counters, custody/location, and open maintenance state from the event stream plus reference data.

R00 does not require event sourcing for every reference object; it requires that operational asset history be durable and replayable enough to reconstruct the canonical asset state.

## 22. Financial Separation

RevenueAgreement describes how rental activity may be reconciled. Rental-use events remain canonical regardless of payment status. Financial reconciliation may reference rental IDs/events but may not create or erase physical-use history.

This enables the owner and venue to audit usage even when payment systems are separate.

## 23. Security and Privacy Contract

Minimum runtime requirements:

- authenticated staff identities in deployed mode;
- role-based authorization;
- device identity/revocation;
- no customer PII requirement for ordinary rentals;
- encrypted network transport where networked;
- protected ownership-transfer and administrative commands;
- backups + restore validation;
- evidence attachment hashing;
- event integrity hashes.

R00 does not define a specific identity provider.

## 24. Import / Export Contract

At minimum, the runtime SHALL support deterministic export of:

- current inventory as CSV and JSON;
- asset events as JSONL;
- maintenance queue as CSV/JSON;
- reservation/manifest data as JSON;
- reconciliation source activity as CSV/JSON.

Exports SHALL preserve stable IDs and timestamps. Import workflows SHALL validate identifiers and SHALL NOT overwrite durable events.

## 25. R00 Acceptance Gates

R00 is implementation-ready only when:

1. all JSON Schema files parse and pass Draft 2020-12 schema validation;
2. the reference SQLite DDL executes from an empty database;
3. every command/event/state name used in the document exists in its catalog;
4. invariants are uniquely identified and machine-readable;
5. checkout/check-in transition guards are unambiguous;
6. ownership/custody/location separation is explicit;
7. idempotency and concurrency behavior are defined;
8. offline conflict outcomes are defined;
9. corrections are append-only;
10. the package contains a SHA-256 manifest.

## 26. R01 Handoff

R01 shall implement the Asset Registry against this contract:

- organizations and locations;
- pair/component registration;
- label identity resolution;
- ownership/custody/location projections;
- inventory import;
- inventory verification;
- R00 command receipts and validation scaffolding required by those operations.

R01 SHALL NOT implement rental, maintenance, reservations, or financial behavior by bypassing the R00 command/event model.

## 27. Non-Claims

This package does **not** claim:

- a backend is running;
- a production database exists;
- QR labels have been field-qualified;
- offline synchronization has been implemented;
- user authentication is deployed;
- a frontend exists;
- payment processing exists;
- revenue percentages have been agreed between parties;
- maintenance thresholds are universally correct.

Those require later implementation and evidence.

---

## Appendix A — Package and Machine-Readable Authority

The frozen package contains the human-readable contract, machine-readable schemas and catalogs, the reference SQLite DDL, validation result, parent binding, SHA-256 manifest, and DOCX rendering of this contract. The schemas and catalogs are intended to be consumed directly by implementation tests in R01+ and should be copied unchanged or vendored with their hashes preserved.
