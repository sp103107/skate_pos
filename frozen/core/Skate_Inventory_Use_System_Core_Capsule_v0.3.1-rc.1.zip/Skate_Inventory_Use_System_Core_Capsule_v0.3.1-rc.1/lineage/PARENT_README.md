# Skate Inventory + Use System — Core Capsule v0.3.0

Status: **FROZEN_INTEGRATION_CANDIDATE**

This package binds the Skate Inventory + Use System foundation and runtime lineage through R02 into one self-describing capsule.

## Included lineage

- F00 Foundation Book v0.1.0
- R00 Core Runtime Contract v0.1.0
- R01 Asset Registry v0.1.0
- R02 Event Ledger + Runtime Spine v0.2.0
- installable runtime wheel `skate-inventory-runtime==0.2.0`

The frozen child ZIPs are preserved byte-for-byte under `artifacts/frozen/`. Their SHA-256 bindings are recorded in `lineage/CHILD_BINDINGS.json`.

## Fast validation

```bash
python boot/validate_capsule.py
```

## Runtime installation

```bash
python -m pip install runtime/dist/skate_inventory_runtime-0.2.0-py3-none-any.whl
skate-registry --help
```

## Capsule surfaces

- `foundation/` — F00 human/product foundation
- `contracts/` — R00 human contract documents
- `artifacts/frozen/` — canonical frozen child release packages
- `runtime/dist/` — installable latest runtime wheel
- `runtime/current/` — extracted R02 convenience projection
- `boot/` — entry, mount, communications, and validation surfaces
- `catalog/` — capability catalog
- `lineage/` — exact child artifact bindings
- `ui_handoff/` — UI00 design handoff
- `validation/` — validation evidence

## Next stage

UI00 is authorized for **frontend architecture and FE/BE mapping design** against R02. R03 remains the next executable runtime stage for rentals.

See `docs/NON_CLAIMS.md` before treating any designed-but-unimplemented surface as active.
