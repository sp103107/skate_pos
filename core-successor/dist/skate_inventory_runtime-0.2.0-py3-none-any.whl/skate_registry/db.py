from __future__ import annotations

import sqlite3
from importlib.resources import files
from pathlib import Path


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def initialize(self) -> None:
        scripts = ["r01_sqlite.sql", "r02_spine.sql"]
        with self.connect() as conn:
            for name in scripts:
                sql_path = files("skate_registry").joinpath("sql", name)
                conn.executescript(sql_path.read_text(encoding="utf-8"))
